import datetime
import uuid
import urllib.request
import urllib.parse
import os
import json

PICTURES_DB = "pictures.json"

# pictures are persisted in the images/ folder
# a json file images/pictures.json holds the pictures object

class Pictures:

    def __init__(self, folder):
        self._pictures_db = os.path.join(folder, PICTURES_DB)
        self._pictures = self.read_db()

    def read_db(self):
        with open(self._pictures_db, "rt") as fp:
            return json.load(fp)
        
    def save_db(self):
        with open(self._pictures_db, "wt") as fp:
            json.dump(self._pictures, fp)
            
    def get_picture(self, id):
        return self._pictures[id]

    def pictures(self):
        pics = [{ 'id': k,
                  'timestamp': self._pictures[k]['timestamp'],
                  'comments': len(self._pictures[k]['comments']) }
                for k in self._pictures]    
        return {'pictures': pics}

    def new_picture_url(self, url, folder):
        id = str(uuid.uuid4())
        now = datetime.datetime.now().isoformat()
        a = urllib.parse.urlparse(url)
        name = os.path.basename(a.path)
        os.mkdir(folder + '/' + id)
        urllib.request.urlretrieve(url, folder + '/' + id + '/' + name)
        self._pictures[id] = {'name': name, 'timestamp': now, 'comments': []}
        self.save_db()
        return {'id': id, 'timestamp': now}

    def comments(self, id):
        pic = self._pictures[id]
        comments = [{ 'comment': comm['comment'],
                      'timestamp': comm['timestamp']}
                    for comm in pic['comments']]
        return {'comments': comments}

    def new_comment(self, id, comment):
        pic = self._pictures[id]
        now = datetime.datetime.now().isoformat()
        pic['comments'].append({'comment': comment, 'timestamp': now})
        self.save_db()
        return {'timestamp': now}
