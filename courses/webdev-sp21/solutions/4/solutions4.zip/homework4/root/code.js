
/*

  TO DO:

  - switch pictures to a map indexed by UUID
  - keep an ordering of the UUIDs?

*/


function elt(id) {
    // useful shortcut
    return document.getElementById(id)
}

class Model {
    constructor() {
        this.pictures = []
        this.current = null
        this.comments = []
        this.fetchedPicturesSubscribers = []
        this.selectedPictureSubscribers = []
        this.fetchedCommentsSubscribers = []
        this.addedCommentSubscribers = []
        this.addedPictureSubscribers = []
    }

    // helper methods
    
    getCurrentPicture() {
        return this.pictures[this.current]
    }

    // subscription methods
    
    subFetchedPictures(f) {
        this.fetchedPicturesSubscribers.push(f)
    }

    subSelectedPicture(f) {
        this.selectedPictureSubscribers.push(f)
    }

    subFetchedComments(f) {
        this.fetchedCommentsSubscribers.push(f)
    }

    subAddedComment(f) {
        this.addedCommentSubscribers.push(f)
    }

    subAddedPicture(f) {
        this.addedPictureSubscribers.push(f)
    }

    // actions
  
    fetchPictures() {
	const pPics = fetch('/pictures')
	const process = (obj) => {
	    console.log('Received pictures =', obj)
            if (obj.pictures.length > 0) {
                this.pictures = obj.pictures
                for (const f of this.fetchedPicturesSubscribers) {
                    f(this.pictures)
                }
            }
	}
	pPics.then((response) => response.json().then((v) => process(v)))
    }

    fetchComments() {
        const idx = this.current
	const pComments = fetch(`/comments/${this.pictures[idx]['id']}`)
	const process = (obj) => {
	    console.log('Received comments =', obj)
            if (obj.comments.length > 0) {
                this.comments = obj.comments
                for (const f of this.fetchedCommentsSubscribers) {
                    f(this.comments)
                }
            }
	}
	pComments.then((response) => response.json().then((v) => process(v)))
    }
    
    selectPicture(idx) {
        this.current = idx
        this.comments = []
        if (idx !== null) { 
            this.fetchComments()
        }
        for (const f of this.selectedPictureSubscribers) {
            f(this.pictures[idx])
        }
    }

    clearPicture(idx) {
        this.current = null
        for (const f of this.selectedPictureSubscribers) {
            f(null)
        }
    }

    addComment(comment) {
        console.log('HERE - with this.current = ', this.current)
        if (this.current >= 0) {
            const pic = this.pictures[this.current]
	    const pAddComment = fetch(`/new-comment/${pic.id}`,
                                      {method: 'POST',
                                       headers: {
                                           'Content-Type': 'application/json'
                                       },
                                       body: JSON.stringify({comment: comment})
                                      })
	    const process = (obj) => {
                this.comments.push({comment: comment, timestamp: obj.timestamp})
                pic.comments += 1
                for (const f of this.fetchedCommentsSubscribers) {
                    f(this.comments)
                }
                for (const f of this.addedCommentSubscribers) {
                    f(pic, comment)
                }
	    }
	    pAddComment.then((response) => response.json().then((v) => process(v)))
        }
    }
    
    addPicture(url) {
        console.log('Adding picture...')
	const pAddPicture = fetch(`/new-picture-url`,
                                  {method: 'POST',
                                   headers: {
                                       'Content-Type': 'application/json'
                                   },
                                   body: JSON.stringify({url: url})
                                  })
	const process = (obj) => {
            const pic = {...obj, comments: 0}
            console.log(pic)
            this.pictures.push(pic)
            for (const f of this.addedPictureSubscribers) {
                f(pic, this.pictures.length - 1)
            }
	}
	pAddPicture.then((response) => response.json().then((v) => process(v)))
    }
}


class PictureListView {
    constructor(m) {
	this.model = m
	this.eltGrid = elt('grid-component')
	m.subFetchedPictures((pics) => this.handleFetchedPictures(pics))
        m.subSelectedPicture((pic) => this.handleSelectedPicture(pic))
        m.subAddedComment((pic) => this.handleAddComment(pic))
        m.subAddedPicture((pic, idx) => this.handleAddPicture(pic, idx))
        // map from picture ID to element
        this.eltPictures = {}
    }

    handleSelectedPicture(pic) {
        console.log('PictureListView.selected', pic)
        if (pic) { 
            this.eltGrid.classList.add('hidden')
        }
        else {
            this.eltGrid.classList.remove('hidden')
        }
    }

    attachPicture(pic, idx) {
        const div = document.createElement('div')
        this.eltPictures[pic.id] = div
        div.classList.add('gridItem')
        const e = document.createElement('img')
        e.setAttribute('src', `/picture/${pic.id}`)
        e.addEventListener('click', () => this.model.selectPicture(idx))
        div.appendChild(e)
        const e2 = document.createElement('div')
        if (pic.comments > 0) {
            e2.innerText = `Comments: ${pic.comments}`
        }
        div.appendChild(e2)
        this.eltGrid.prepend(div)
    }

    handleFetchedPictures(pics) {
        let idx = 0
        for (const p of pics) {
            this.attachPicture(p, idx)
            idx += 1
        }
    }

    handleAddComment(pic) {
        const id = pic.id
        const div = this.eltPictures[id].querySelector('div')
        div.innerText = `Comments: ${pic.comments}`
    }

    handleAddPicture(pic, idx) {
        this.attachPicture(pic, idx)
    }
}


class PictureAddView {
    constructor(m) {
	this.model = m
        this.eltComponent = elt('picture-add-component')
	this.eltButton = elt('picture-add')
        this.eltInput = elt('picture-add-input')
        m.subSelectedPicture((pic) => this.handleSelectedPicture(pic))
        this.eltButton.addEventListener('click', () => this.addPicture())
    }

    handleSelectedPicture(pic) {
        if (pic) { 
            this.eltComponent.classList.add('hidden')
        }
        else {
            this.eltComponent.classList.remove('hidden')
        }
    }

    addPicture() {
        const url = this.eltInput.value
        if (url && url.trim()) {
            this.eltInput.value = ''
            this.model.addPicture(url)
        }
    }
}


class PictureView {
    constructor(m) {
	this.model = m
	this.eltPic = elt('picture-component')
	this.eltPicImg = elt('picture-img')
        this.eltPicBack = elt('picture-back')
        this.eltPicComments = elt('picture-comments')
        this.eltPicInput = elt('picture-input')
	m.subSelectedPicture((pic) => this.handleSelectedPicture(pic))
	m.subFetchedComments((pic) => this.handleFetchedComments(pic))
        this.eltPic.classList.add('hidden')
        this.eltPicBack.addEventListener('click', () => this.back())
        this.eltPicInput.addEventListener('change', () => this.input())
    }

    back() {
        this.model.selectPicture(null)
    }

    input() {
        const text = this.eltPicInput.value
        if (text && text.trim()) {
            this.model.addComment(text)
        }
    }

    clearComments() {
        console.log('Clearing comments')
        while (this.eltPicComments.firstChild) {
            this.eltPicComments.removeChild(this.eltPicComments.firstChild)
        }
        this.eltPicInput.value = ''
    }

    handleFetchedComments(comments) {
        this.clearComments()
        // reverse a _copy_ of the array
        const lasttwo = (s) => (s.slice(s.length -2, s.length))
        for (const comm of comments.slice().reverse()) {
            const e = document.createElement('div')
            e.classList.add('comment')
            const dt = document.createElement('p')
            dt.classList.add('date')
            const d = new Date(comm.timestamp)
            dt.innerText = `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()} ${d.getHours()}h${lasttwo('00' + d.getMinutes())}`
            e.appendChild(dt)
            const txt = document.createElement('p')
            txt.classList.add('comment')
            txt.innerText = comm.comment
            e.appendChild(txt)
            this.eltPicComments.appendChild(e)
        }
    }

    handleSelectedPicture(pic) {
        console.log('PictureView.selected', pic)
        if (pic) {
            this.clearComments()
            this.eltPic.classList.remove('hidden')
            this.eltPicImg.setAttribute('src', `/picture/${pic.id}`)
        }
        else {
            this.eltPic.classList.add('hidden')
        }
    }
}    

    
function init() {
    const model = new Model()
    const picListV = new PictureListView(model)
    const picV = new PictureView(model)
    const picAddV = new PictureAddView(model)
    model.fetchPictures()
}

// put all the initialization code in a function called
// when the document finishes loading
// (you're sure all elements have been created before your code kicks in)

window.addEventListener('load', init)
