import os
import json
import uuid
from flask import Flask, jsonify, send_from_directory, request, redirect

from core import Pictures

app = Flask(__name__)

PORT = 8080
PUBLIC_FOLDER = 'root'
IMAGES_FOLDER = 'images'


@app.route('/pictures')
def pictures_route():
    result = PICTURES.pictures()
    return jsonify(result)


@app.route('/picture/<string:id>')
def image_route(id):
    pic = PICTURES.get_picture(id)
    return send_from_directory(IMAGES_FOLDER + '/' + id, pic['name'])


@app.route('/new-picture-url', methods=['POST'])
def new_picture_url_route():
    body = request.get_json()
    result = PICTURES.new_picture_url(body['url'], IMAGES_FOLDER)
    return jsonify(result)


@app.route('/comments/<string:id>')
def comments_route(id):
    result = PICTURES.comments(id)
    return jsonify(result)


@app.route('/new-comment/<string:id>', methods=['POST'])
def new_comment_route(id):
    body = request.get_json()
    result = PICTURES.new_comment(id, body['comment'])
    return jsonify(result)


@app.route('/')
def root_route():
    return redirect('/index.html')


@app.route('/<path:p>')
def generic_route(p):
    return send_from_directory(PUBLIC_FOLDER, p)

PICTURES = Pictures(IMAGES_FOLDER)

app.run(port=PORT)
