import os
import json
from flask import Flask, jsonify, send_from_directory, request, redirect
from pictures_mem import AvailablePicturesMem
from pictures_sql import AvailablePicturesSQL
from pictures_ar import AvailablePicturesAR
from pictures_orm import AvailablePicturesORM

PORT = 8080
IMAGES_FOLDER = 'images'
ROOT_FOLDER = 'root'

PICTURES = AvailablePicturesORM()

app = Flask(__name__)

@app.route('/pictures')
def get_pictures_route():
    pics = PICTURES.get_pictures()
    result = {'pictures': pics}
    return jsonify(result)


@app.route('/add-picture', methods=['POST'])
def add_picture_route():
    pictDesc = request.get_json()
    PICTURES.add_picture(pictDesc['name'], pictDesc['url'])
    return jsonify({'status': 'ok'})


@app.route('/image/<string:name>')
def image_route(name):
    return send_from_directory(IMAGES_FOLDER, name)


# Serve the frontend

@app.route('/')
def root_route():
    return redirect('/index.html')

@app.route('/<path:p>')
def static_route(p):
    return send_from_directory(ROOT_FOLDER, p)


app.run(port=PORT)
