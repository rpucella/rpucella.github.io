import sqlite3
import pymongo

_DBNAME = 'pics.db'
_FNAME = 'pics.txt'
_MONGODB = 'persistence-demo'

class AvailablePicturesORM:

    def __init__(self):
        #storage = SQLiteStorage(_DBNAME)        
        #storage = FileSystemStorage(_FNAME)
        storage = MongoDBStorage(_MONGODB)
        self.picsRepo = PictureRepository(storage)
    
    def get_pictures(self):
        pics = self.picsRepo.find_all()
        result = [p.as_dict() for p in pics]
        return sorted(result, key=lambda r:r['name'])

    def add_picture(self, name, url):
        pic = Picture(name, url)
        self.picsRepo.create(pic)
        
        
class Picture:

    def __init__(self, name, url):
        self.name = name
        self.url = url

    def as_dict(self):
        return {'name': self.name, 'url': self.url}

    @staticmethod
    def from_dict(d):
        return Picture(d['name'], d['url'])


    
class PictureRepository:

    def __init__(self, storage):
        self._storage = storage

    def create(self, pic):
        self._storage.create_picture(pic.as_dict())

    def find_all(self):
        ps = self._storage.find_all_pictures()
        return [Picture.from_dict(p) for p in ps]


    
class SQLiteStorage:

    def __init__(self, dbname):
        self._dbname = dbname
        
    def create_picture(self, p):
        conn = sqlite3.connect(self._dbname)
        curs = conn.cursor()
        curs.execute('''INSERT INTO pictures VALUES (?, ?)''', [p['name'], p['url']])
        conn.commit()
        conn.close()

    def find_all_pictures(self):
        conn = sqlite3.connect(self._dbname)
        curs = conn.cursor()
        curs.execute('''SELECT name, url FROM pictures''')
        rows = curs.fetchall()
        conn.close()
        return [{'name': r[0], 'url': r[1]} for r in rows]
    

class MongoDBStorage:

    def __init__(self, dbname):
        self._client = pymongo.MongoClient('mongodb://localhost:27017')
        self._db = self._client[dbname]
            
    def create_picture(self, p):
        self._db.pictures.insert_one(p)

    def find_all_pictures(self):
        curs = self._db.pictures.find()
        return [r for r in curs]

    
class FileSystemStorage:

    def __init__(self, fname):
        self._fname = fname
            
    def create_picture(self, p):
        with open(self._fname, 'at') as fp:
            fp.write(p['name'] + '\n')
            fp.write(p['url'] + '\n')

    def find_all_pictures(self):
        with open(self._fname, 'rt') as fp:
            ps = []
            line = fp.readline()
            while line:
                url = fp.readline()
                ps.append({'name': line, 'url': url})
                line = fp.readline()
            return ps

