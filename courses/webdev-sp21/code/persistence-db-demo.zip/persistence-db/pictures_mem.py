

class AvailablePicturesMem:

    def __init__(self):
        self._pictures = []

    def get_pictures(self):
        return sorted(self._pictures, key=lambda r:r['name'])

    def add_picture(self, name, url):
        self._pictures.append({'name': name, 'url': url})

