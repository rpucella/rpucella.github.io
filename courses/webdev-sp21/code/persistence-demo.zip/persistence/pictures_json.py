import json

class PicturesJson:
    
    def __init__(self, fname, port):
        self._fname = fname
        self._pictures = self._read()

    def _read(self):
        with open(self._fname, 'rt') as fp:
            js = json.load(fp)
        return js['pictures']
        
    def _write(self):
        js = {'pictures': self._pictures}
        with open(self._fname, 'wt') as fp:
            json.dump(js, fp)
        
    def get_pictures(self):
        return self._pictures

    def add_picture(self, name, url):
        self._pictures.append({'name': name, 'url': url})
        self._write()
        
