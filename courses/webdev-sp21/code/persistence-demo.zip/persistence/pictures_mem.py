class PicturesMem:

    def __init__(self, port):
        def mkUrl(name):
            return 'http://localhost:{}/image/{}'.format(port, name)
        self._pictures = [
            {
                'name': 'Attila the Hun',
                'url': mkUrl('attila.jpg')
            },
            {
                'name': 'Alaric the Visigoth',
                'url': mkUrl('alaric.jpg')
            },
            {
                'name': 'Theodoric the Ostrogoth',
                'url': mkUrl('theodoric.png')
            }
        ]

    def get_pictures(self):
        return self._pictures

    def add_picture(self, name, url):
        self._pictures.append({'name': name, 'url': url})

        
