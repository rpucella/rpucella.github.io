class PicturesAppend:
    
    def __init__(self, fname, port):
        self._fname = fname
        # self._pictures = self._read()

    def _read(self):
        pics = []
        with open(self._fname, 'rt') as fp:
            line = fp.readline()
            while line:
                name = line
                url = fp.readline()
                pics.append({'name': name, 'url': url})
                line = fp.readline()
        return pics
        
    def _write_pic(self, name, url):
        with open(self._fname, 'at') as fp:
            fp.write(name + '\n')
            fp.write(url + '\n')
        
    def get_pictures(self):
        return self._read()
        #return self._pictures

    def add_picture(self, name, url):
        # self._pictures.append({'name': name, 'url': url})
        self._write_pic(name, url)
        
