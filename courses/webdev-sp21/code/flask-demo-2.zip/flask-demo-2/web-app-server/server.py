import os
import json
from flask import Flask, jsonify, send_from_directory, request

app = Flask(__name__)

# Some magic to make make it possible to make calls to the endpoint
# from outside the server (CORS)
@app.after_request
def add_header(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = '*'
    return response        

PORT = 8080

IMAGES_FOLDER = 'images'

def mkUrl(name):
    return 'http://localhost:{}/image/{}'.format(PORT, name)

PICTURES = [
    {
        'name': 'Cat',
        'url': mkUrl('cat.png')
    },
    {
        'name': 'Dog',
        'url': mkUrl('dog.jpg')
    },
    {
        'name': 'Attila the Hun',
        'url': mkUrl('attila.jpg')
    },
    {
        'name': 'Alaric the Visigoth',
        'url': mkUrl('alaric.jpg')
    },
    {
        'name': 'Theodoric the Ostrogoth',
        'url': mkUrl('theodoric.png')
    }
]

print(json.dumps(PICTURES, indent=2))

@app.route('/pictures')
def get_pictures_route():
    result = {'pictures': PICTURES}
    return jsonify(result)


@app.route('/add-picture', methods=['POST'])
def add_picture_route():
    pictDesc = request.get_json()
    print('Received {} / {}'.format(pictDesc['name'], pictDesc['url']))
    PICTURES.append({'name': pictDesc['name'], 'url': pictDesc['url']})
    return jsonify({'status': 'ok'})


@app.route('/image/<string:name>')
def image_route(name):
    return send_from_directory(IMAGES_FOLDER, name)


app.run(port=PORT)


