import os
import json
import uuid
from flask import Flask, jsonify, send_from_directory, request, redirect, make_response
from flask import render_template

import core

PORT = 8080
PUBLIC_FOLDER = 'static'
IMAGES_FOLDER = 'images'

app = Flask(__name__)


#
# Endpoints to get/put data
#

@app.route('/pictures')
def pictures_route():
    result = core.pictures()
    return jsonify(result)


@app.route('/new-picture-url', methods=['POST'])
def new_picture_url_route():
    body = request.get_json()
    result = core.new_picture_url(body['url'], IMAGES_FOLDER)
    return jsonify(result)


@app.route('/comments/<string:id>')
def comments_route(id):
    result = core.comments(id)
    return jsonify(result)


@app.route('/new-comment/<string:id>', methods=['POST'])
def new_comment_route(id):
    body = request.get_json()
    result = core.new_comment(id, body['comment'])
    return jsonify(result)


#
# Endpoint to show a picture via <img src=...>
#

@app.route('/picture/<string:id>')
def image_route(id):
    pic = core.get_picture(id)
    return send_from_directory(IMAGES_FOLDER + '/' + id, pic['name'])


#
# Endpoints that deliver HTML documents for navigation
#
# /gallery     --> show picture gallery
# /<id>        --> show picture <id> with comments
#

# templates are automatically found in the templates/ directory

def add_cookie(result, name, value):
    # adds a Set-Cookie: <name>=<value> header to a response
    resp = make_response(result)
    resp.set_cookie(name, value)
    return resp

@app.route('/')
def root_route():
    return redirect('/gallery')

@app.route('/gallery')
def gallery_route():
    result = core.pictures()
    visited_cookie = request.cookies.get('visited')
    if visited_cookie:
        visited = visited_cookie.split('|')
    else:
        visited = []
    return render_template('gallery.jj2',
                           pictures=result['pictures'],
                           visited=visited)

@app.route('/<string:id>')
def uuid_route(id):
    pic = core.get_picture(id)
    visited_cookie = request.cookies.get('visited')
    if visited_cookie:
        visited = set(visited_cookie.split('|'))
    else:
        visited = set()
    result = render_template('picture.jj2',
                             pic=pic,
                             id=id)
    return add_cookie(result, 'visited', '|'.join(visited | {id}))

app.run(port=PORT)
