import datetime
import uuid
import urllib.request
import urllib.parse
import os

PICTURES = {
    'c4c0de04-a523-4128-a0c5-c917b08332e0': {
        'name': 'dog.jpg',
        'timestamp': datetime.datetime(2021, 3, 1, 10, 0, 0),
        'comments': [
            {
                'comment': 'hello world',
                'timestamp': datetime.datetime.now()
            }
        ]
    },
    '7c76774f-a051-44e4-abbe-e4e19548a03d': {
        'name': 'mercury.jpg',
        'timestamp': datetime.datetime(2021, 4, 1, 10, 0, 0),
        'comments': []
    },
    'cbc17b2d-de7f-489b-85bb-8fb57c68eb5e': {
        'name': 'venus.jpg',
        'timestamp': datetime.datetime(2021, 4, 1, 10, 0, 0),
        'comments': []
    },
    '4cd7abc2-78e0-47a6-8b93-e14eb32bf590': {
        'name': 'earth.jpg',
        'timestamp': datetime.datetime(2021, 4, 1, 10, 0, 0),
        'comments': []
    },
    '7f568f35-d378-4256-b124-f62ea13e1008': {
        'name': 'mars.jpg',
        'timestamp': datetime.datetime(2021, 4, 1, 10, 0, 0),
        'comments': []
    },
    '1cbeb3e9-1a14-407d-aec3-8a3980f8768e': {
        'name': 'jupiter.jpg',
        'timestamp': datetime.datetime(2021, 4, 1, 10, 0, 0),
        'comments': []
    },
    '1bbdb887-5142-44b5-96d5-e9f9e1f386a1': {
        'name': 'saturn.jpg',
        'timestamp': datetime.datetime(2021, 4, 1, 10, 0, 0),
        'comments': []
    },
    '3a4ef980-49a0-48c1-9b69-27d7f4b88eb4': {
        'name': 'uranus.jpg',
        'timestamp': datetime.datetime(2021, 4, 1, 10, 0, 0),
        'comments': []
    },
    '46ea4981-7729-49f9-9700-9a80abe5f0a1': {
        'name': 'neptune.jpg',
        'timestamp': datetime.datetime(2021, 4, 1, 10, 0, 0),
        'comments': []
    }
}


def get_picture(id):
    return PICTURES[id]


def pictures():
    pics = [{ 'id': k,
              'timestamp': PICTURES[k]['timestamp'].isoformat(),
              'comments': len(PICTURES[k]['comments']) }
            for k in PICTURES]    
    return {'pictures': pics}


def new_picture_url(url, folder):
    id = str(uuid.uuid4())
    now = datetime.datetime.now()
    a = urllib.parse.urlparse(url)
    name = os.path.basename(a.path)
    os.mkdir(folder + '/' + id)
    urllib.request.urlretrieve(url, folder + '/' + id + '/' + name)
    PICTURES[id] = {'name': name, 'timestamp': now, 'comments': []}
    return {'id': id, 'timestamp': now.isoformat()}


def comments(id):
    pic = PICTURES[id]
    comments = [{ 'comment': comm['comment'],
                  'timestamp': comm['timestamp'].isoformat() }
                for comm in pic['comments']]
    return {'comments': comments}


def new_comment(id, comment):
    pic = PICTURES[id]
    now = datetime.datetime.now()
    pic['comments'].append({'comment': comment, 'timestamp': now})
    return {'timestamp': now.isoformat()}
