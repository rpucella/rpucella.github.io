
Requires Python 3.

Install flask using pip

    pip install flask

or set up a virtual environment to install it.

Start the server by running

    python server.py

in this directory. It will start the server on port 8080.

Once the server is running, go to http://localhost:8080 in your browser.

