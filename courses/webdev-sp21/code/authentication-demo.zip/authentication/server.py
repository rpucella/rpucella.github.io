import os
import json
import uuid
from flask import Flask, jsonify, send_from_directory, request, redirect, make_response
from flask import render_template
from hashlib import sha256

import core

PORT = 8080
IMAGES_FOLDER = 'images'

# this obviously should go in a database...

def hash_password(pwd):
    h = sha256()
    h.update(pwd)
    return h.hexdigest()

USERS = {
    'riccardo': hash_password(b'xyzzy'),
    'vicky': hash_password(b'123')
}

SESSION_STATE = {
}

app = Flask(__name__)


#
# Endpoints to get/put data
#

@app.route('/pictures')
def pictures_route():
    result = core.pictures()
    return jsonify(result)


@app.route('/new-picture-url', methods=['POST'])
def new_picture_url_route():
    body = request.get_json()
    result = core.new_picture_url(body['url'], IMAGES_FOLDER)
    return jsonify(result)


@app.route('/comments/<string:id>')
def comments_route(id):
    result = core.comments(id)
    return jsonify(result)


@app.route('/new-comment/<string:id>', methods=['POST'])
def new_comment_route(id):
    body = request.get_json()
    result = core.new_comment(id, body['comment'])
    return jsonify(result)


#
# Endpoint to show a picture via <img src=...>
#

@app.route('/picture/<string:id>')
def image_route(id):
    pic = core.get_picture(id)
    return send_from_directory(IMAGES_FOLDER + '/' + id, pic['name'])


#
# Cookie functions
#

def add_cookie(result, name, value):
    # adds a Set-Cookie header to a response
    resp = make_response(result)
    resp.set_cookie(name, value)
    return resp

def get_cookie(name, default):
    # get a cookie from the request if it exists
    #  return default if it doesn't
    result = request.cookies.get(name)
    return result if result is not None else default


#
# Session information
#

def create_session(name):
    sessionId = str(uuid.uuid4())
    SESSION_STATE[sessionId] = {'name': name,
                                'visited': set()}
    return sessionId

def get_name():
    # get name out of the session corresponding to the current request
    sessionId = get_cookie('sessionId', None)
    if not sessionId or sessionId not in SESSION_STATE:
        return None
    return SESSION_STATE[sessionId]['name']

def get_visited():
    # get visited info from the session corresponding to the current request
    sessionId = get_cookie('sessionId', None)
    if not sessionId or sessionId not in SESSION_STATE:
        return set()
    return SESSION_STATE[sessionId]['visited']

def record_visited(id):
    # add id to visited info for the session corresponding to the current request
    sessionId = get_cookie('sessionId', None)
    if not sessionId or sessionId not in SESSION_STATE:
        return
    SESSION_STATE[sessionId]['visited'].add(id)

def check_password(name, password):
    return hash_password(password.encode('utf-8')) == USERS[name]


#
# Endpoints that deliver HTML documents for navigation
#
# /login       --> show login screen
# /gallery     --> show picture gallery
# /<id>        --> show picture <id> with comments
#
# templates are automatically found in the templates/ directory

@app.route('/')
def root_route():
    return redirect('/login')

@app.route('/login')
def login_route():
    # check if we're logged in
    # if so, go to /gallery
    name = get_name()
    if name:
        return redirect('/gallery')
    return render_template('login-password.jj2')

@app.route('/login-action', methods=['POST'])
def login_action_route():
    # could put this on the same route as above, /login but as a POST
    # that's _usually_ what's done, but it's a bit confusing at first
    name = request.form['name']
    password = request.form['password']
    if name not in USERS:
        # error
        return render_template('login-password.jj2', error='User does not exist')
    if not check_password(name, password):
        # error
        return render_template('login-password.jj2', error='Wrong password')
    sessionId = create_session(name)
    result = redirect('/gallery')
    return add_cookie(result, 'sessionId', sessionId)


@app.route('/logout')
def logout():
    result = redirect('/login')
    # clear session
    return add_cookie(result, 'sessionId', '')


@app.route('/gallery')
def gallery_route():
    # check if we're logged in
    # if not, go to /login
    name = get_name()
    if not name:
        return redirect('/login')
    
    visited = get_visited()
    result = core.pictures()
    return render_template('gallery.jj2',
                           pictures=result['pictures'],
                           visited=visited,
                           name=name)

@app.route('/<string:id>')
def uuid_route(id):
    # check if we're logged in
    # if not, go to /login
    name = get_name()
    if not name:
        return redirect('/login')
    
    record_visited(id)
    pic = core.get_picture(id)
    return render_template('picture.jj2',
                           pic=pic,
                           id=id,
                           name=name)


app.run(port=PORT)
