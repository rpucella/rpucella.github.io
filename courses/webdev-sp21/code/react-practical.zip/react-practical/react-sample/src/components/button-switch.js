import {Component} from 'react'

export class ButtonSwitch extends Component {

    constructor(props) {
	super(props)
	this.state = { showing: 0 }    // 0 or 1
    }
    
    render() {

        const thing1 = this.props.thing1
	const thing2 = this.props.thing2
	      
        const row = { display: 'flex',
                      flexDirection: 'row',
                      justifyContent: 'space-evenly',
		      alignItems: 'center',
                      width: '100%'
                    }

	const handleClick = () => {
	    this.setState({showing: 1 - this.state.showing})
	}
		      
        return ( <div style={row}>
  	           <button onClick={handleClick}>Switch</button>
  		   { this.state.showing === 0 ? thing1 : thing2 }
                 </div> )
    }
}

