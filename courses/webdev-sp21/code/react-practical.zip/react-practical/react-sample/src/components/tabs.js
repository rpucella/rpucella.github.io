import {Component} from 'react'

export class Tabs extends Component {

    constructor(props) {
	super(props)
	this.state = { showing: 0 }    // 0 or 1
    }
    
    render() {

        const content = this.props.content
        
        const column = {
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
        }
        
        const row = {
            display: 'flex',
            flexDirection: 'row',
	    alignItems: 'flex-end',
            margin: '32px 0'
        }

        const selected = {
            borderTop: '1px solid black',
            borderLeft: '1px solid black',
            borderRight: '1px solid black',
            borderBottom: 'none',
            padding: '16px',
            width: '200px',
            textAlign: 'center'
        }
		      
        const notSelected = {
            borderBottom: '1px solid black',
            padding: '16px',
            width: '200px',
            textAlign: 'center',
            cursor: 'pointer'
        }

	const makeTab = (obj, i) => {
	    if (this.state.showing === i) {
		return <div style={selected}>{obj.title}</div>
	    } else {
		const handleClick = () => this.setState({showing: i})
		return <div style={notSelected} onClick={handleClick}>{obj.title}</div>
	    }
	}
        
        return ( <div style={column}>
                   <div style={row}>
                     { content.map(makeTab) }
                   </div>
                   { content[this.state.showing].component }
                 </div> )
    }
}

