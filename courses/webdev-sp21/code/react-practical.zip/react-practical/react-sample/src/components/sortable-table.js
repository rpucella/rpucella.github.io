import {Component}  from 'react'

export class SortableTable extends Component {
    
    constructor(props) {
        super(props)
        this.state = { sorting: -1 }
    }

    sortRows(col) {
	// sort the original rows
        const newRows = this.props.rows.slice()
        newRows.sort((a, b) => a[col].toString().localeCompare(b[col].toString()))
        return newRows
    }
    
    render() {
        const rows = this.state.sorting < 0 ? this.props.rows : this.sortRows(this.state.sorting)
        const headers = this.props.headers
        const sortByColumn = (col) => {
            this.setState({sorting: col})
	}
        return ( <table>
                   <thead>
                     <tr>
                       { headers.map((h, col) => <th onClick={() => sortByColumn(col)}>{ h }</th>) }
                     </tr>
                   </thead>
                   <tbody>
                     { rows.map(r => <tr>{ r.map(item => <td>{ item }</td>) }</tr>) }
                   </tbody>
                 </table> )
    }
}

