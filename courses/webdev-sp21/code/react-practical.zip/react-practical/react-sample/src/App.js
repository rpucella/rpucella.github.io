import './App.css'
import {Component}  from 'react'

import {SortableTable} from './components/sortable-table'
import {ButtonSwitch} from './components/button-switch'
import {Tabs} from './components/tabs'

class App extends Component {
    
    render() {
        const rows = [['Alice', 25, 'Software Engineer'],
                      ['Bob', 30, 'Builder'],
                      ['Charlie', 21, 'Painter'],
                      ['Darlene', 32, 'Singer']]
        
        const headers = ['Name', 'Age', 'Profession']

        const rows2 = [['Rubicon', 'Tom Holland', 2003],
                       ['The Storm before the Storm', 'Mike Duncan', 2017],
                       ['The Penelopiad', 'Margaret Atwood', 2005],
                       ['Augustus', 'John Williams', 1972],
                       ['SPQR', 'Mary Beard', 2015],
                       ['Julian', 'Gore Vidal', 1964]]
        
        const headers2 = ['Title', 'Author', 'Publication Year']

	const bigred = {
	    backgroundColor: 'red',
	    color: 'white',
	    fontSize: '36px'
	}

	const table1 = <SortableTable rows={rows} headers={headers} />
        const random = <div style={bigred}>Hello Riccardo!</div>

        return (
          <ButtonSwitch thing1={table1} thing2={random} />
        )
    }
}

export default App
