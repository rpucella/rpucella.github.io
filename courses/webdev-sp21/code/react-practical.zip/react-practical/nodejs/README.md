
To build:

   npm install

then 

   node test.js
