const helper = require('./helper.js')
const dayjs = require('dayjs')

function helloWorld() {
    console.log('Hello world!')
    helper.me('Riccardo')
    const now = dayjs()
    console.log(`The current time is ${now.format()}`)
}

helloWorld()
