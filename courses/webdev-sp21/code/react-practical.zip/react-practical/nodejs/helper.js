
function me(name) {
    console.log(`My name is ${name}`)
}

exports.me = me
