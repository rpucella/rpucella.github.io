import {Component} from 'react'
import {Card} from './card'

export class List extends Component {
    render() {
        const {name, cards, index, addNewCard} = this.props
        const layout = {
            flex: '0 0 200px',
            width: '200px',
            margin: '0 16px',
            padding: '16px 16px',
            backgroundColor: '#aaaaaa',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center'
        }
        return <div style={layout}>
                   {name}
                   {cards.map(c => <Card title={c.title} description={c.description} />)}
                   <button onClick={() => addNewCard(index)}>New card</button>
               </div>
    }
}

