import {Component} from 'react'

export class Header extends Component {
    render()  {
        const cList = this.props.lists.length
        const cCard = this.props.lists.reduce((r, lst) => r + lst.cards.length, 0)
        const layout = {
            fontSize: '48px',
            textAlign: 'center',
            backgroundColor: 'black',
            color: 'white'
        }
        return <div style={layout}>Board ({cList} lists, {cCard} cards)</div>
    }
}
