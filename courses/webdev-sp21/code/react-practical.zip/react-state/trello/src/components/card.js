import {Component} from 'react'

export class Card extends Component {
  render() {
    const {title, description} = this.props
    const layout = {
      width: '150px',
      margin: '8px 0',
      padding: '16px 16px',
      backgroundColor: '#eeeeee',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start'
    }
    const titleStyle = {
      alignSelf: 'center',
      fontWeight: 'bold',
      marginBottom: '8px'
    }
    return <div style={layout}>
             <div style={titleStyle}>{title}</div>
             <div>{description}</div>
           </div>
  }
}
    
