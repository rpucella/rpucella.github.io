import {Component} from 'react'
import {List} from './list'

export class Board extends Component {
    render() {
        const {lists, addNewList, addNewCard} = this.props
        const layout = {
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'flex-start',
            margin: '32px 16px'
        }
        return <div style={layout}>
                   { lists.map((lst, idx) => <List index={idx} name={lst.name} cards={lst.cards} addNewCard={addNewCard} />) }
                   <button onClick={addNewList}>New List</button>
               </div>
    }
}
