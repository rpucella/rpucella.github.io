import {Component} from 'react'
import {Header} from './components/header'
import {Board} from './components/board'

class App extends Component {
    constructor(props) {
        super(props)
        // lists  = array of objects {name: ..., cards: [card, ...]}
        this.state = { lists:[] }    
        this.nextAvailable = 1
    }

    newList() {
        const {lists} = this.state
        const id = this.nextAvailable
        this.nextAvailable += 1
        const new_list = {name: 'List ' + id, cards: []}
        lists.push(new_list)
        // update the lists in the state
        this.setState({lists: lists})
    }

    newCard (listIndex) {
        const {lists} = this.state
        const id = this.nextAvailable
        this.nextAvailable += 1
        const new_card = {id: id, title: 'Card '+  id, description: 'Some random text for card ' + id}
        lists[listIndex].cards.push(new_card)
        this.setState({lists: lists})
    }
    
    render() {
        const column = {
            display: 'flex',
            flexDirection: 'column'
        }
        return <div style={column}>
                   <Header lists={this.state.lists} />
                   <Board lists={this.state.lists} addNewList={() => this.newList()} addNewCard={(idx) => this.newCard(idx)} />
               </div>
    }
}

export default App
