import {Component} from 'react'

class ShowCount extends Component {
    render() {
        const count = this.props.count
        const largeGreen = {
            fontSize: '96px',
            color: 'green'
        }
        return <div style={largeGreen}>
                   {count}
               </div>
    }
}

class BumpCount extends Component {
    render() {
        const bump = this.props.bumpAction
        const button = {
            marginTop: '16px',
            width: '96px',
            height: '40px',
            color: 'white',
            backgroundColor: 'blue'
        }
        return <button style={button} onClick={bump}>Bump Count</button>
    }
}


class App extends Component {
    constructor(props) {
        super(props)
        this.state = {counter: 0}
    }

    render() {
        const counter = this.state.counter
        const column = {
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center'
        }
        const bump = () => this.setState({counter: counter + 1})
        return <div style={column}>
                   <ShowCount count={counter} />
                   <BumpCount bumpAction={bump} />
               </div>
    }
}

export default App;
