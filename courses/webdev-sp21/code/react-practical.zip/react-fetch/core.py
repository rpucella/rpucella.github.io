import datetime
import uuid
import urllib.request
import urllib.parse
import os

PICTURES = {
    'c4c0de04-a523-4128-a0c5-c917b08332e0': {
        'name': 'dog.jpg',
        'timestamp': datetime.datetime(2021, 3, 1, 10, 0, 0),
        'comments': [
        ]
    }
}


def get_picture(id):
    return PICTURES[id]


def pictures():
    pics = [{ 'id': k,
              'timestamp': PICTURES[k]['timestamp'].isoformat(),
              'comments': len(PICTURES[k]['comments']) }
            for k in PICTURES]    
    return {'pictures': pics}


def new_picture_url(url, folder):
    id = str(uuid.uuid4())
    now = datetime.datetime.now()
    a = urllib.parse.urlparse(url)
    name = os.path.basename(a.path)
    os.mkdir(folder + '/' + id)
    urllib.request.urlretrieve(url, folder + '/' + id + '/' + name)
    PICTURES[id] = {'name': name, 'timestamp': now, 'comments': []}
    return {'id': id, 'timestamp': now.isoformat()}


def comments(id):
    pic = PICTURES[id]
    comments = [{ 'comment': comm['comment'],
                  'timestamp': comm['timestamp'].isoformat() }
                for comm in pic['comments']]
    return {'comments': comments}


def new_comment(id, comment):
    pic = PICTURES[id]
    now = datetime.datetime.now()
    pic['comments'].append({'comment': comment, 'timestamp': now})
    return {'timestamp': now.isoformat()}
