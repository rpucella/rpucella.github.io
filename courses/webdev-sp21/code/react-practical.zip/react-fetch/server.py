import os
import json
import uuid
from flask import Flask, jsonify, send_from_directory, request, redirect

import core

PORT = 8080
PUBLIC_FOLDER = 'react-frontend/build'
IMAGES_FOLDER = 'images'

app = Flask(__name__, static_folder=PUBLIC_FOLDER + '/static')

# static_folder gets around a sometimes annoying flask feature
# where /static/... paths are not  caught by a <path> route but
# instead fetch directly from a 'static/' folder at root level

@app.route('/pictures')
def pictures_route():
    result = core.pictures()
    return jsonify(result)


@app.route('/picture/<string:id>')
def image_route(id):
    pic = core.get_picture(id)
    return send_from_directory(IMAGES_FOLDER + '/' + id, pic['name'])


@app.route('/new-picture-url', methods=['POST'])
def new_picture_url_route():
    body = request.get_json()
    result = core.new_picture_url(body['url'], IMAGES_FOLDER)
    return jsonify(result)


@app.route('/comments/<string:id>')
def comments_route(id):
    result = core.comments(id)
    return jsonify(result)


@app.route('/new-comment/<string:id>', methods=['POST'])
def new_comment_route(id):
    body = request.get_json()
    result = core.new_comment(id, body['comment'])
    return jsonify(result)


@app.route('/')
def root_route():
    return redirect('/index.html')


@app.route('/<path:p>')
def generic_route(p):
    return send_from_directory(PUBLIC_FOLDER, p)


app.run(port=PORT)
