import {Component} from 'react'
import styled from 'styled-components'
import {Thumbnails} from './components/thumbnails'
import {AddPicture} from './components/add-picture'
import {Picture} from './components/picture'

const Layout = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
`

const Header = styled.h1`
    width: 100%;
    text-align: center;
    padding: 16px 0;
    background-color: black;
    color: white;
    margin: 0 0 24px 0;
`

class App extends Component {
    constructor(props) {
        super(props)
        this.state = {
	    loaded: false,
            pictures: [],
	    selected: null      // null if no picture selected, picture object if picture selected
        }
    }

    render() {
	
        const fetchPictures = () => { 
	    fetch('/pictures')
		.then((response) => response.json())
                .then((v) => this.setState({loaded: true, pictures: v.pictures}))
        }

        const addPicture = (url) => { 
            const {pictures} = this.state
	    const pAddPicture = fetch(`/new-picture-url`,
                                      {method: 'POST',
                                       headers: {
                                           'Content-Type': 'application/json'
                                       },
                                       body: JSON.stringify({url: url})
                                      })
	    pAddPicture
		.then((response) => response.json())
                .then((v) => { 
                    const pic = {...v, comments: 0}
                    pictures.push(pic)
                    this.setState({pictures: pictures})
                })
        }

	const selectPicture = (pic) => {
	    this.setState({selected: pic})
	}
	
	const clearPicture = (pic) => {
	    this.setState({selected: null})
	}
	
	if (!this.state.loaded) {
	    fetchPictures()
	    return <Layout>
		       <Header> Homework 4 Revisited </Header>
		   </Layout>
	}
	if (this.state.selected) {
	    return <Layout>
		       <Header> Homework 4 Revisited </Header>
		       <Picture pic={this.state.selected} clearPicture={clearPicture}/>
		   </Layout>
	}
	return <Layout>
		   <Header> Homework 4 Revisited </Header>
		   <AddPicture addPicture={addPicture} />
		   <Thumbnails pics={this.state.pictures} selectPicture={selectPicture} />
	       </Layout>
    }
}

export default App
