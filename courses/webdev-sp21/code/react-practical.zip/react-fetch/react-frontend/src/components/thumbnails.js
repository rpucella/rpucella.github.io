import {Component} from 'react'
import styled from 'styled-components'
import {Thumbnail} from './thumbnail'

const Layout = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;

    & > * { 
        margin-bottom: 24px;
    }
`

const Grid = styled.div`
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
`

export class Thumbnails extends Component {
    render() {
        const {pics, selectPicture} = this.props
        return <Layout>
		   <Grid> {pics.map(p => <Thumbnail pic={p} selectPicture={selectPicture} />)} </Grid>
               </Layout>
    }
}
