import {Component} from 'react'
import styled from 'styled-components'

const Layout = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;

    & > * { 
       margin-bottom: 24px;
    }
`

const Row = styled.div`
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: space-between;
`

const TightRow = styled.div`
    display: flex;
    flex-direction: row;
    align-items: center;
    width: 100%;
`

const Image = styled.img`
    height: 75vh;
    object-fit: contain;
    object-position: top;
    width: 40vw;
    margin: 0 16px;
`

const Comments = styled.div`
    display: flex;
    flex-direction: column;
    width: 40vw;
    margin: 0 16px;
`

const Button = styled.button`
    width: 200px;
    height: 48px;
    font-size: 16px;
`

const NarrowButton = styled.button`
    width: 80px;
    height: 48px;
    font-size: 16px;
`

const Input = styled.input`
    font-size: 16px;
    padding: 8px;
    height: 48px;
    box-sizing: border-box;
    flex: 1 0 auto;
`

const Comment = styled.div`
    margin: 8px 0 0 0;
    padding: 8px;
    background-color: #eeeeee;
`

export class Picture extends Component {
    constructor(props) {
        super(props)
        this.state = {comment: '', comments: [], loaded: false}
    }

    render() {
        const {pic, clearPicture} = this.props
        const fetchComments = () =>  {
	    const pComments = fetch(`/comments/${pic.id}`)
	    pComments.then((response) => response.json())
                .then((v) => this.setState({comments: v.comments, loaded: true}))
        }
        const addComment = () => {
	    const pAddComment = fetch(`/new-comment/${pic.id}`,
                                      {method: 'POST',
                                       headers: {
                                           'Content-Type': 'application/json'
                                       },
                                       body: JSON.stringify({comment: this.state.comment})
                                      })
	    pAddComment.then(response => response.json())
                .then(v => {
                    const {comment, comments} = this.state
                    comments.push({comment: comment, timestamp: v.timestamp})
                    // should also bump the count # on comments for the picture in the thumbnail gallery!
                    // how do we do that?
                    this.setState({comment: '', comments: comments})
                })
        }
        const handleComment = (evt) => {
            this.setState({comment: evt.target.value})
        }
        if (!this.state.loaded) {
            fetchComments()
            return <Layout>
                       <Button onClick={clearPicture}> Back </Button>
                       <Row>
			   <Image src={`picture/${pic.id}`} />
			   <Comments> (Loading) </Comments>
                       </Row>
		   </Layout>            
        }
        return <Layout>
                   <Button onClick={clearPicture}> Back </Button>
                   <Row>
                       <Image src={`picture/${pic.id}`} />
                       <Comments>
                           <TightRow>
                               <Input  type="text" placeholder="Please type in a comment" value={this.state.comment} onChange={handleComment} />
                               <NarrowButton onClick={addComment}>Send</NarrowButton>
                           </TightRow>
                           {this.state.comments.map(c => <Comment>{c.comment}</Comment>)}
                       </Comments>
                   </Row>
               </Layout>
    }
}

