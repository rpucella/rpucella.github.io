import {Component} from 'react'
import styled from 'styled-components'

const Row = styled.div`
    display: flex;
    flex-direction: row;
    align-items: center;
`

const Input = styled.input`
    font-size: 16px;
    padding: 8px;
    width: 400px;
    height: 48px;
    box-sizing: border-box;
`

const Button = styled.button`
    width: 200px;
    height: 48px;
    font-size: 16px;
`

export class AddPicture extends Component {
    constructor(props) {
        super(props)
        this.state = {url: ''}
    }
    
    render() {
        const {addPicture} = this.props
        const handleNewValue = (evt) => {
            this.setState({url: evt.target.value})
        }
        const handleClick = () => {
            addPicture(this.state.url)
            this.setState({url: ''})
        }
        return <Row>
                   <Input placeholder="URL" value={this.state.url} onChange={handleNewValue} />
                   <Button onClick={handleClick}>Add Picture</Button>
               </Row>
    }
}

