import {Component} from 'react'
import styled from 'styled-components'

const Layout = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
    width: 200px;
    height: 240px;
    flex: 0 0;
    border: 1px solid #888888;
    padding: 16px;
    margin: 16px;
    background-color: #dddddd;
`

const Image = styled.img`
    width: 200px;
    height: 200px;
    object-fit: contain;
    flex: 0 0;
    cursor: pointer
`

export class Thumbnail extends Component {
    render() {
        const {pic, selectPicture} = this.props
	const handleClick = () => {
	    selectPicture(pic)
	}
        return <Layout>
                   <Image src={`picture/${pic.id}`} onClick={handleClick} />
                   { pic.comments > 0 ? <div>Comments: {pic.comments}</div> : null }
               </Layout>
    }
}
