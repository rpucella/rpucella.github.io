import os
from flask import Flask, jsonify, send_from_directory

app = Flask(__name__)

# Some magic to make make it possible to make calls to the endpoint
# from outside the server (CORS)
@app.after_request
def add_header(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    return response        

PORT = 8081
IMAGES_FOLDER= 'images-with-names'


@app.route('/available-images')
def available_images():
    # construct list of images from existing subfolders
    directories = os.listdir(IMAGES_FOLDER)
    result = []
    for dir in directories:
        try:
            with open('{}/{}/NAME'.format(IMAGES_FOLDER, dir), 'rt') as fp:
                name = fp.read().strip()
                item = {
                    'name': name,
                    'url': 'http://localhost:{}/image/{}'.format(PORT, dir)
                }
                result.append(item)
        except:
            pass
    return jsonify(result)


@app.route('/image/<int:id>')
def image(id):
    # all files in images-with-names/<id>
    content = os.listdir('{}/{}'.format(IMAGES_FOLDER, id))
    for c in content:
        if c != 'NAME':
            # send the file
            return send_from_directory('{}/{}'.format(IMAGES_FOLDER, id), c)


app.run(port=PORT)


