import os
import json
import uuid
from flask import Flask, jsonify, send_from_directory, request, redirect
from flask import render_template

import core

PORT = 8080
PUBLIC_FOLDER = 'static'
IMAGES_FOLDER = 'images'

app = Flask(__name__)


#
# Endpoints to get/put data
#

@app.route('/pictures')
def pictures_route():
    result = core.pictures()
    return jsonify(result)


@app.route('/new-picture-url', methods=['POST'])
def new_picture_url_route():
    body = request.get_json()
    result = core.new_picture_url(body['url'], IMAGES_FOLDER)
    return jsonify(result)


@app.route('/comments/<string:id>')
def comments_route(id):
    result = core.comments(id)
    return jsonify(result)


@app.route('/new-comment/<string:id>', methods=['POST'])
def new_comment_route(id):
    body = request.get_json()
    result = core.new_comment(id, body['comment'])
    return jsonify(result)


#
# Endpoint to show a picture via <img src=...>
#

@app.route('/picture/<string:id>')
def image_route(id):
    pic = core.get_picture(id)
    return send_from_directory(IMAGES_FOLDER + '/' + id, pic['name'])


#
# Endpoints that delivery HTML documents for navigation
#
# /     --> show picture gallery
# /<id> --> show picture <id> with comments
#

# templates are automatically found in the templates/ directory

@app.route('/')
def root_route():
    result = core.pictures()
    return render_template('main.jj2',
                           pictures=result['pictures'])

@app.route('/<string:id>')
def uuid_route(id):
    pic = core.get_picture(id)
    return render_template('picture.jj2',
                           pic=pic,
                           id=id)


app.run(port=PORT)
