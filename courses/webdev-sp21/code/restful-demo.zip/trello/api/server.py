import os
import json
from flask import Flask, jsonify, send_from_directory, request, redirect

from board import Board, List, Card

PORT = 8080
BOARD = Board()


app = Flask(__name__)

@app.route('/lists', methods=['GET'])
def GET_lists():
    result = {'lists': BOARD.get_lists()}
    return jsonify(result)

@app.route('/lists', methods=['POST'])
def POST_lists():
    body = request.get_json()
    lst = List(body['name'])
    BOARD.add_list(lst)
    result = {'id': lst.id}
    return jsonify(result)

@app.route('/lists/<int:id>', methods=['GET'])
def GET_list(id):
    result = BOARD.get_list(id).as_full_dict()
    return jsonify(result)

@app.route('/lists/<int:id>', methods=['DELETE'])
def DELETE_list(id):
    result = BOARD.delete_list(id)
    return 'List was successfully deleted'

@app.route('/lists/<int:list_id>/cards', methods=['GET'])
def GET_cards(list_id):
    result = {'cards': BOARD.get_list(list_id).get_cards()}
    return jsonify(result)

@app.route('/lists/<int:list_id>/cards', methods=['POST'])
def POST_cards(list_id):
    body = request.get_json()
    lst = BOARD.get_list(list_id)
    crd = Card(body['name'], body['description'], body['priority'], body['due_date'])
    lst.add_card(crd)
    result = {'id': crd.id}
    return jsonify(result)

@app.route('/lists/<int:list_id>/cards/<int:card_id>', methods=['GET'])
def GET_card(list_id, card_id):
    result = BOARD.get_list(list_id).get_card(card_id).as_full_dict()
    return jsonify(result)

@app.route('/lists/<int:list_id>/cards/<int:card_id>', methods=['DELETE'])
def DELETE_card(list_id, card_id):
    result = BOARD.get_list(list_id).delete_card(card_id)
    return 'Card was successfully deleted'

app.run(port=PORT)
