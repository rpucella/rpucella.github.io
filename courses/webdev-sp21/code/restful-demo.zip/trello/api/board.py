import datetime

_FORMAT = '%m/%d/%Y'


class Board:
    def __init__(self):
        self._lists = {}

    def get_lists(self):
        return [lst.as_small_dict() for lst in self._lists.values()]
    
    def add_list(self, lst):
        self._lists[lst.id] = lst

    def get_list(self, id):
        return self._lists[id]

    def delete_list(self, id):
        del self._lists[id]

        
class List:

    # class variable tracking the next available listID
    _next_id = 100
    
    def __init__(self, name):
        self.name = name
        self.created = datetime.date.today().strftime(_FORMAT)
        self.id = List._next_id
        List._next_id += 1
        self._cards = {}

    def get_cards(self):
        return [c.as_small_dict() for c in self._cards.values()]

    def add_card(self, c):
        self._cards[c.id] = c

    def get_card(self, id):
        return self._cards[id]

    def delete_card(self, id):
        del self._cards[id]

    def as_full_dict(self):
        return {'name': self.name,
                'created': self.created,
                'id': self.id}

    def as_small_dict(self):
        return {'name': self.name,
                'id': self.id}

        
class Card:

    # class variable tracking the next available cardID
    _next_id = 1000
    
    def __init__(self, name, description, priority, due_date):
        self.name = name
        self.description = description
        self.priority = priority
        self.due_date = due_date
        self.created = datetime.date.today().strftime(_FORMAT)
        self.id = Card._next_id
        Card._next_id += 1

    def as_full_dict(self):
        return {'name': self.name,
                'description': self.description,
                'priority': self.priority,
                'due_date': self.due_date,
                'created': self.created,
                'id': self.id}

    def as_small_dict(self):
        return {'name': self.name,
                'id': self.id}
    
    
