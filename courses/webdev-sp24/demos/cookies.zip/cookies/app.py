from flask import Flask, send_from_directory, request, redirect, make_response
import json
from dbs.pictures_fs import AvailablePictures

app = Flask(__name__, static_folder=None)

BUILD_FOLDER = 'frontend/build'

COOKIE_PREFS = 'pv_prefs'

PICTURES = AvailablePictures()

@app.route("/")
def get_root():
    return redirect("/index.html")


@app.route("/pictures")
def get_pictures():
    # Get a cookie using request.cookies.get()
    pv_prefs = request.cookies.get(COOKIE_PREFS)
    if pv_prefs:
        prefs = json.loads(pv_prefs)
        alpha = prefs['alpha'] if 'alpha' in prefs else False
    else:
        alpha = False
    pics = PICTURES.get_pictures()
    if alpha:
        pics = sorted(pics, key=lambda r: r['name'])
    return {
        'pictures': pics,
        'preferences': {
            'alpha': alpha
        }
    }

@app.route("/add-picture", methods=["POST"])
def addPicture():
    body = request.json
    PICTURES.add_picture(body['name'], body['url'])
    return "ok"


@app.route("/set-preferences", methods=["POST"])
def setPreferences():
    # Get the body, store in a cookie
    body = request.json
    resp = make_response("ok")
    resp.set_cookie(COOKIE_PREFS, json.dumps(body))
    return resp


@app.route("/<path:p>")
def serveFile(p):
    ##print(f"asking for file {p}")
    return send_from_directory(BUILD_FOLDER, p)



def wrap_cookie(result, name, value):
    # adds a Set-Cookie: <name>=<value> header to a response
    resp = make_response(result)
    resp.set_cookie(name, value)
    return resp
