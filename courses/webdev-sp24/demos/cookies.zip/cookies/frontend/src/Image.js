
function Image({pic}) {
  return (
    <div className="image-view">
      <img src={pic.url} />
      <h2>Name of pic: {pic.name}</h2>
    </div>
  )
}

export default Image
