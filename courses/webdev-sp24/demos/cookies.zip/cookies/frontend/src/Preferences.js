import {useState} from 'react'

function Preferences({prefs, getPictures}) {
  console.log(`alpha = ${prefs?.alpha}`)
  const handleChange = (evt) => {
    const isChecked = evt.target.checked
    fetch('/set-preferences', {
      method: 'POST',
      headers: {
        "Content-Type": 'application/json'
      },
      body: JSON.stringify({'alpha': isChecked})
    }).then(() => getPictures())
  }
  return (
    <div className="boxed">
      <div className="control-horizontal">
        <input type="checkbox" checked={!!prefs?.alpha} onChange={handleChange} />
        <label>Order alphabetically</label>
      </div>
    </div>
  )
}

export default Preferences
