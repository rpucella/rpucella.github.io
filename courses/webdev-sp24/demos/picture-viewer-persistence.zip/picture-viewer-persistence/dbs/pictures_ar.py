import sqlite3

# ORM: ACTIVE RECORDS

_DBNAME = 'pictures.db'

class AvailablePictures:

    def get_pictures(self):
        pics = Picture.find_all()
        result = [{'name': p.name, 'url': p.url} for p in pics]
        return result

    def add_picture(self, name, url):
        p = Picture(name, url)
        p.save()


# Active Record for pictures table

def _sql_connect():
    return sqlite3.connect(_DBNAME)

class Picture:

    def __init__(self, name, url):
        self.name = name
        self.url = url

    def save(self):
        conn = _sql_connect()
        try:
            curs = conn.cursor()
            curs.execute("""
                insert into pictures values (?, ?)
            """, [self.name, self.url])
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def find_all():
        conn = _sql_connect()
        try:
            curs = conn.cursor()
            pics = []
            curs.execute("""
                select * from pictures
            """)
            rows = curs.fetchall()
            pics = [Picture(r[0], r[1]) for r in rows]
            return pics
        finally:
            conn.close()
