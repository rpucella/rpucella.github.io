

# NO PERSISTENCE - IN MEMORY ONLY


class AvailablePictures:

    def __init__(self):
        # Initializiing
        self._pictures = [
            {'name': 'Cat',
             'url': 'images/cat.png'},
            {'name': 'Dog',
             'url': 'images/dog.jpg'}
        ]

    def get_pictures(self):
        return self._pictures

    def add_picture(self, name, url):
        self._pictures.append({'name': name, 'url': url})
