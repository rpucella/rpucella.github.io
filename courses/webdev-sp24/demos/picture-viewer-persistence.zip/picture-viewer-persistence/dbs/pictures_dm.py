import sqlite3
import csv

# ORM: DATA MAPPER

_DBNAME = 'pictures.db'
_FILE = 'pictures.csv'

class AvailablePictures:

    def __init__(self):
        # Choose the kind of repository you want to use.
        self._repo = PictureRepositorySQL(_DBNAME)
        #self._repo = PictureRepositoryFS(_FILE)

    def get_pictures(self):
        pics = self._repo.find_all()
        result = [{'name': p.name, 'url': p.url} for p in pics]
        return result

    def add_picture(self, name, url):
        pic = Picture(name, url)
        self._repo.save(pic)


class Picture:

    # A Picture is an abstraction of a picture in storage.

    def __init__(self, name, url):
        self.name = name
        self.url = url


class PictureRepositorySQL:

    # A Picture repository implements the query against
    # the chosen storage mechanism.

    def __init__(self, dbname):
        self._dbname = dbname

    def save(self, pic):
        # Picture -> ()
        conn = sqlite3.connect(self._dbname)
        curs = conn.cursor()
        curs.execute("""
             insert into pictures values (?, ?)
        """, [pic.name, pic.url])
        conn.commit()
        conn.close()

    def find_all(self):
        conn = sqlite3.connect(self._dbname)
        curs = conn.cursor()
        curs.execute("""
            select name, url from pictures
        """)
        rows = curs.fetchall()
        conn.close()
        return [Picture(r[0], r[1]) for r in rows]


class PictureRepositoryFS:

    # A Picture repository implements the query against
    # the chosen storage mechanism.

    def __init__(self, fname):
        self._fname = fname

    def save(self, pic):
        # Picture -> ()
        with open(_FILE, 'at') as fp:
            csvw = csv.writer(fp, delimiter='\t')
            csvw.writerow([pic.name, pic.url])

    def find_all(self):
        with open(_FILE, 'rt') as fp:
            csvr = csv.reader(fp, delimiter='\t')
            return [Pictures(r[0], r[1]) for r in csvr]
