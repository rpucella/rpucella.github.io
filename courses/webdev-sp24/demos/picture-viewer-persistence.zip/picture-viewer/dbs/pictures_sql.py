import sqlite3

# DIRECT RELATIONAL DATABASE

_DBNAME = 'pictures.db'

class AvailablePictures:

    def __init__(self):
        pass

    def get_pictures(self):
        conn = sqlite3.connect(_DBNAME)
        curs = conn.cursor()
        curs.execute("""
            select * from pictures
        """)
        rows = curs.fetchall()
        conn.close()
        return [{'name': r[0], 'url': r[1]} for r in rows]

    def add_picture(self, name, url):
        conn = sqlite3.connect(_DBNAME)
        curs = conn.cursor()
        # use a prepared statement/query
        curs.execute("""
            insert into pictures values (?, ?)
        """, [name, url])
        conn.commit()
        conn.close()
