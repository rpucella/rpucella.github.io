from flask import Flask, send_from_directory, request, redirect
from dbs.pictures_dm import AvailablePictures

app = Flask(__name__, static_folder=None)

BUILD_FOLDER = 'frontend/build'

PICTURES = AvailablePictures()

@app.route("/")
def get_root():
    return redirect("/index.html")

@app.route("/pictures")
def get_pictures():
    pics = PICTURES.get_pictures()
    return {'pictures': pics}

@app.route("/add-picture", methods=["POST"])
def addPicture():
    body = request.json
    ##print(body)
    PICTURES.add_picture(body['name'], body['url'])
    return "ok"

@app.route("/<path:p>")
def serveFile(p):
    ##print(f"asking for file {p}")
    return send_from_directory(BUILD_FOLDER, p)
