import {useState} from 'react'

function NewPicture({addPic, deleteCurrentPic}) {
  const [name, setName] = useState('')
  const [url, setUrl] = useState('')
  console.log('Rendering NewPicture')
  const handleClickAdd = (evt) => {
    if (name && url) {
      addPic(name, url)
      setName('')
      setUrl('')
      const bodyValue = {
        name: name,
        url: url
      }
      fetch('/add-picture', {
        method: 'POST',
        headers: {
          "Content-Type": 'application/json'
        },
        body: JSON.stringify(bodyValue)
      })
    }
  }
  const handleClickDelete = () => {
    deleteCurrentPic()
  }
  const handleChangeName = (evt) => {
    setName(evt.target.value)

  }
  const handleChangeUrl = (evt) => {
    setUrl(evt.target.value)
  }
  return (
    <div className="boxed">
      <div className="control">
        <label>Name:</label>
        <input type="text" value={name} onChange={handleChangeName} />
      </div>
      <div className="control">
        <label>URL:</label>
        <input type="text" value={url} onChange={handleChangeUrl} />
      </div>
      <button onClick={handleClickAdd}>Add picture</button>
      <button onClick={handleClickDelete}>Delete picture</button>
    </div>
  )
}

export default NewPicture
