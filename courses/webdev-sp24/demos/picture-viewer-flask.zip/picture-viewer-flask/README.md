
# React frontend + Flask backend


To install with pipenv:

1. Run `pipenv install` from the root folder. This requires having 
    - this requires python 3 installed on your system
2. Go into the `frontend` folder
    - that's where the React frontend is stored
3. Run `npm install` to install the packages needed by the frontedn
4. Run `npm run build` to create the frontend bundle
5. Go back to the root folder
6. Run `pipenv shell` to enter the virtual environment containing `flask`
7. Run `flask run` to start the web application server.
8. Navigate to `localhost:5000`

To install without pipenv:

1. Run `pip3 install flask` to install flask globally
2. Go into the `frontend` folder
    - that's where the React frontend is stored
3. Run `npm install` to install the packages needed by the frontedn
4. Run `npm run build` to create the frontend bundle
5. Go back to the root folder
6. Run `flask run` to start the web application server.
7. Navigate to `http://localhost:5000`

Two things to note:

- the front end is a completely separate codebase, and lives in folder `frontend`
- every time you modify the frontend code, you need to re-build it in order to 
  see it through web application server.
  
