from flask import Flask, send_from_directory, request, redirect, make_response
from dbs.pictures_fs import AvailablePictures
import uuid
from hashlib import sha256

app = Flask(__name__, static_folder=None)

BUILD_FOLDER = 'frontend/build'

PICTURES = AvailablePictures()

# this obviously should go in a database...

def hash_password(pwd):
    h = sha256()
    h.update(pwd)
    return h.hexdigest()

USERS = {
    'riccardo': hash_password(b'xyzzy'),
    'vicky': hash_password(b'123')
}

SESSION_STATE = {
}

@app.route("/")
def get_root():
    return redirect("/index.html")


@app.route("/pictures")
def get_pictures():
    # Get a cookie using request.cookies.get()
    pics = PICTURES.get_pictures()
    return {
        'pictures': pics
    }

@app.route("/add-picture", methods=["POST"])
def addPicture():
    body = request.json
    ##print(body)
    PICTURES.add_picture(body['name'], body['url'])
    return "ok"

@app.route("/set-preferences", methods=["POST"])
def setPreferences():
    # Get the body, store in a cookie
    return "ok"

@app.route("/login")
def login():
    name = get_name()
    if name:
        return redirect("/index.html")
    return send_from_directory(BUILD_FOLDER, "login.html")

@app.route("/login", methods=["POST"])
def post_login():
    name = request.form['name']
    password = request.form['password']
    print(f"Calling POST /login with {name} and {password}")
    if name not in USERS:
        # error
        return redirect("/login.html")
    if not check_password(name, password):
        # error
        return redirect("/login.html")
    sessionId = create_session(name)
    result = redirect('/index.html')
    return wrap_cookie(result, 'sessionId', sessionId)

@app.route("/<path:p>")
def serveFile(p):
    # Check if we're logged in.
    # If not, redirect to the login page.
    name = get_name()
    if not name:
        return redirect("/login")
    return send_from_directory(BUILD_FOLDER, p)


#
# Cookie functions
#

def wrap_cookie(result, name, value):
    # adds a Set-Cookie header to a response
    resp = make_response(result)
    resp.set_cookie(name, value)
    return resp

def get_cookie(name, default):
    # get a cookie from the request if it exists
    #  return default if it doesn't
    result = request.cookies.get(name)
    return result if result is not None else default

#
# Session functions
#

def create_session(name):
    sessionId = str(uuid.uuid4())
    SESSION_STATE[sessionId] = {
        'name': name
    }
    return sessionId

def get_name():
    # get name out of the session corresponding to the current request
    sessionId = get_cookie('sessionId', None)
    if not sessionId or sessionId not in SESSION_STATE:
        return None
    return SESSION_STATE[sessionId]['name']

def check_password(name, password):
    return hash_password(password.encode('utf-8')) == USERS[name]
