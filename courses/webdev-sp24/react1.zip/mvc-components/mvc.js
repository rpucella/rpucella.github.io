function elt(id) {
  // useful shortcut
  return document.getElementById(id)
}

function create(tag, attr) {
  const elt = document.createElement(tag)
  if (attr) {
    for (let at of Object.keys(attr)) {
      elt.setAttribute(at, attr[at])
    }
  }
  return elt
}



class Model {
  constructor() {
    this.current = null
    this.pictures = []
    // list of functions to call when picture changes
    this.changedPictureSubscribers = []
    // list of functions to call when picture is added
    this.addedPictureSubscribers = []
  }

  // helper methods

  getPicture() {
    return this.pictures[this.current]
  }

  // subscription methods

  subAddedPicture(f) {
    this.addedPictureSubscribers.push(f)
  }

  subChangedPicture(f) {
    this.changedPictureSubscribers.push(f)
  }

  // actions

  changePicture(v) {
    this.current = v
    // go through every function in the list changedPictureSubscribers
    // and call each function with the index of the current picture
    this.changedPictureSubscribers.forEach((f) => { f(v, this.pictures[v]) })
  }

  addPicture(pict) {
    this.pictures.push(pict)
    const idx = this.pictures.length - 1
    this.addedPictureSubscribers.forEach((f) => { f(idx, pict) })
    this.changePicture(idx)
  }
}




class App {
  constructor(m) {
    this.model = m
    this.render(m)
  }

  render(m) {
    const div = create('div')
    // <h1>
    const h1 = create('h1', {
      'class': 'title'
    })
    h1.innerText = 'MVC Components Demo'
    div.appendChild(h1)
    // <div layout>
    const div_layout = create('div', {
      'class': 'layout'
    })
    div.appendChild(div_layout)
    const div_left_column = create('div', {
      'class': 'left-column'
    })
    div_layout.appendChild(div_left_column)
    const selector = new Selection(m)
    div_left_column.appendChild(selector.root())
    const new_pic = new NewPicture(m)
    div_left_column.appendChild(new_pic.root())
    const div_right_column = create('div', {
      'class': 'right-column'
    })
    div_layout.appendChild(div_right_column)
    const image = new Image(m)
    div_right_column.appendChild(image.root())
    const thumbnails = new Thumbnails(m)
    div_right_column.appendChild(thumbnails.root())
    this.elt = div
  }

  root() {
    return this.elt
  }
}



class Selection {
  constructor(m) {
    this.model = m
    this.render(m)
    this.eltSelect.addEventListener('change', () => { this.handleSelectionChange() })
    m.subAddedPicture((idx, pict) => { this.handleAddedPicture(idx, pict) })
    m.subChangedPicture((v) => { this.handleChangedPicture(v) })
  }

  render(m) {
    const div_boxed = create('div', {
      'class': 'boxed'
    })
    const div_control = create('div', {
      'class': 'control'
    })
    div_boxed.appendChild(div_control)
    const label = create('label')
    label.innerText = 'Select picture:'
    const select = create('select')
    div_control.appendChild(label)
    div_control.appendChild(select)
    this.elt = div_boxed
    this.eltSelect = select
  }

  root() {
    return this.elt
  }

  handleSelectionChange() {
    const value = this.eltSelect.value
    this.model.changePicture(+value)
  }

  handleChangedPicture(v) {
    this.eltSelect.value = v
  }

  handleAddedPicture(index, pict) {
    const newOption = create('option', {
      'value': index
    })
    newOption.innerText = pict.name
    this.eltSelect.appendChild(newOption)
  }

}




class Image {
  constructor(m) {
    this.model = m
    this.render(m)
    m.subChangedPicture((idx, pict) => { this.handleChangedPicture(idx, pict) })
  }

  render(m) {
    const div = create('div', {
      'class': 'image-view'
    })
    const img = create('img', {
      'class': 'main'
    })
    div.appendChild(img)
    const h2 = create('h2')
    div.appendChild(h2)
    this.elt = div
    this.eltUrl = img
    this.eltName = h2
  }

  root() {
    return this.elt
  }

  handleChangedPicture(idx, pict) {
    this.eltName.innerText = pict.name
    this.eltUrl.setAttribute('src', pict.url)
  }
}





class NewPicture {
  constructor(m) {
    this.model = m
    this.render(m)
    this.eltButton.addEventListener('click', () => { this.handleClick() })
  }

  root() {
    return this.elt
  }

  render(m) {
    const div = create('div', {
      'class': 'boxed'
    })
    const control1 = create('div', {
      'class': 'control'
    })
    div.appendChild(control1)
    const label1 = create('label')
    label1.innerText = 'Name:'
    const input1 = create('input', {
      'type': 'text',
    })
    control1.appendChild(label1)
    control1.appendChild(input1)
    const control2 = create('div', {
      'class': 'control'
    })
    div.appendChild(control2)
    const label2 = create('label')
    label2.innerText = 'URL:'
    const input2 = create('input', {
      'type': 'text',
    })
    control2.appendChild(label2)
    control2.appendChild(input2)
    const button = create('button')
    button.innerText = 'Add picture'
    div.appendChild(button)
    this.elt = div
    this.eltButton = button
    this.eltNewName = input1
    this.eltNewUrl = input2
  }


  _getPictureInfo() {
    const name = this.eltNewName.value
    const url = this.eltNewUrl.value
    if (!name || !url) {
      return false
    }
    return { name: name, url: url }
  }

  _clearInputs() {
    this.eltNewName.value = ''
    this.eltNewUrl.value = ''
  }

  handleClick() {
    const pict = this._getPictureInfo()
    if (pict) {
      this.model.addPicture(pict)
      this._clearInputs()
    }
  }
}



class Thumbnails {
  constructor(m) {
    this.model = m
    this.render(m)
    m.subAddedPicture((idx, pict) => { this.handleAddedPicture(idx, pict) })
    m.subChangedPicture((idx, pict) => { this.handleChangedPicture(idx, pict) })
  }

  root() {
    return this.elt
  }

  render(m) {
    const thumbnails = create('div', {
      'class': 'thumbnails'
    })
    this.elt = thumbnails
  }

  handleAddedPicture(idx, pict) {
    const thumb = new Thumbnail(this.model, idx, pict)
    this.elt.appendChild(thumb.root())
  }

  handleChangedPicture(idx, pict) {
    console.log(`changed picture to ${idx}`)
    const imgs = this.elt.querySelectorAll('img.thumbnail')
    for (let img of imgs) {
      img.classList.remove('highlight')
    }
    imgs[idx].classList.add('highlight')
  }
}



class Thumbnail {
  constructor(m, idx, pict) {
    this.model = m
    this.index = idx
    this.render(m, pict.url)
    this.elt.addEventListener('click', () => { this.handleClick() })
  }

  root() {
    return this.elt
  }

  render(m, url) {
    const img = create('img', {
      'src': url,
      'class': 'thumbnail'
    })
    this.elt = img
  }

  handleClick() {
    this.model.changePicture(this.index)
  }
}


function init() {
  const model = new Model()
  const app = new App(model)
    document.getElementById('app').appendChild(app.root())
  // initialization
  model.addPicture({
    name: 'Cat',
    url: 'images/cat.png'
  })
  model.addPicture({
    name: 'Dog',
    url: 'images/dog.jpg'
  })
  model.changePicture(0)
}

// put all the initialization code in a function called
// when the document finishes loading
// (you're sure all elements have been created before your code kicks in)

window.addEventListener('load', init)
// alternatively:
// window.onload = init
