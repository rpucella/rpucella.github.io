
window.onload = init

const useState = React.useState
const e = React.createElement

function init() { 
    const domContainer = document.querySelector('#app')
    const root = ReactDOM.createRoot(domContainer)
    root.render(e(App, {}, null))
}

const initialPics = [
  {
    name: 'Cat',
    url: 'images/cat.png'
  },
  {
    name: 'Dog',
    url: 'images/dog.jpg'
  }
]


function App() {
  const [pics, setPics] = useState(initialPics)
  const [current, setCurrent] = useState(0)
  const addPic = (name, url) => {
    const newPics = [...pics, {name: name, url:url}]
    setPics(newPics)
    setCurrent(newPics.length - 1)
  }
  return e('div', {},
	   e('h1', {className: 'title'}, 'React Demo'),
	   e('div', {className: 'layout'},
	     e('div', {className: 'left-column'},
	       e(Selection, {pics: pics,
			     current: current,
			     setCurrent: setCurrent}),
	       e(NewPicture, {addPic: addPic })),
	     e('div', {className: 'right-column'},
	       e(Image, {pics: pics, current: current}))))
}


function Selection({pics, current, setCurrent}) {
  return e('div', {className: 'boxed'},
	   e('div', {className: 'control'},
	     e('label', {}, 'Select picture:'),
	     e('select', {value: current,
			  onChange: (evt) => setCurrent(evt.target.value)},
	       pics.map((p, i) => e('option', {'value': i, 'key': i}, p.name)))))
}


function Image({pics, current}) {
  const pic = pics[current]
  return e('div', {className: 'image-view'},
	   e('img', {src: pic.url}),
	   e('h2', {}, pic.name))
}


function NewPicture({addPic}) {
  const [name, setName] = useState('')
  const [url, setUrl] = useState('')
  const clickHandler = (evt) => {
    if (name && url) {
      addPic(name, url)
      setName('')
      setUrl('')
    }
  }
  return e('div', {className: 'boxed'},
	   e('div', {className: 'control'},
	     e('label', {}, 'Name:'),
	     e('input', {type: 'text',
			 value: name,
			 onChange: (evt) => setName(evt.target.value)})),
	   e('div', {className: 'control'},
	     e('label', {}, 'URL:'),
	     e('input', {type: 'text',
			 value: url,
			 onChange: (evt) => setUrl(evt.target.value)})),
	   e('button', {onClick: clickHandler}, 'Add picture'))
}

