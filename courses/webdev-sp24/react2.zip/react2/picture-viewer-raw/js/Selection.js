
function Selection({pics, current, setCurrent}) {
  console.log('Rendering Selection')
  const handleChange = (evt) => {
    // The + is to convert the value (which is a string)
    // to a number.
    setCurrent(+evt.target.value)
  }
  const mkOption = (pic, i) => {
    return e('option', {'value': i, 'key': i}, pic.name)
  }
  return e('div', {className: 'boxed'},
	   e('div', {className: 'control'},
	     e('label', {}, 'Select picture:'),
	     e('select', {value: current, onChange: handleChange},
	       pics.map(mkOption))))
}
