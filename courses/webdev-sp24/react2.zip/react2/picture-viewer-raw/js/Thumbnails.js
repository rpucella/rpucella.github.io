
function Thumbnails({pics, current, setCurrent}) {
  console.log('Rendering Thumbnails')
  const mkThumbnail = (pic, i) => {
    return e(Thumbnail, {key: i, index: i, pic, current, setCurrent})
  }
  return e('div', {className: 'thumbnails'}, pics.map(mkThumbnail))
}


function Thumbnail({pic, index, current, setCurrent}) {
  console.log('Rendering Thumbnail')
  const className = index === current ? 'highlight thumbnail' : 'thumbnail'
  const handleClick = () => {
    setCurrent(index)
  }
  return e('img', {src: pic.url, className, onClick: handleClick})
}
