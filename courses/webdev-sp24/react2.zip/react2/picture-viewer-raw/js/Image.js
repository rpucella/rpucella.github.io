
function Image({pic}) {
  console.log('Rendering Image')
  return e('div', {className: 'image-view'},
	   e('img', {src: pic.url}),
	   e('h2', {}, pic.name))
}
