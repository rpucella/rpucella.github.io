
const initialPics = [
  {
    name: 'Cat',
    url: 'images/cat.png'
  },
  {
    name: 'Dog',
    url: 'images/dog.jpg'
  }
]

function App() {
  // State
  const [pics, setPics] = useState(initialPics)
  const [current, setCurrent] = useState(0)
  // Helper function to add a new picture to the state
  console.log('Rendering App')
  const addPic = (name, url) => {
    const newPics = [...pics, {name: name, url:url}]
    setPics(newPics)
    setCurrent(newPics.length - 1)
  }
  return e('div', {},
	   e('h1', {className: 'title'}, 'React Demo'),
	   e('div', {className: 'layout'},
	     e('div', {className: 'left-column'},
	       e(Selection, {pics, current, setCurrent}),
	       e(NewPicture, {addPic})),
	     e('div', {className: 'right-column'},
	       e(Image, {pic: pics[current]}),
               e(Thumbnails, {pics, current, setCurrent}))))
}
