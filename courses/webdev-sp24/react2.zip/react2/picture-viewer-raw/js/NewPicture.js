

function NewPicture({addPic}) {
  const [name, setName] = useState('')
  const [url, setUrl] = useState('')
  console.log('Rendering NewPicture')
  const handleClick = (evt) => {
    if (name && url) {
      addPic(name, url)
      setName('')
      setUrl('')
    }
  }
  const handleChangeName = (evt) => {
    setName(evt.target.value)

  }
  const handleChangeUrl = (evt) => {
    setUrl(evt.target.value)
  }
  return e('div', {className: 'boxed'},
	   e('div', {className: 'control'},
	     e('label', {}, 'Name:'),
	     e('input', {type: 'text', value: name,
			 onChange: handleChangeName})),
	   e('div', {className: 'control'},
	     e('label', {}, 'URL:'),
	     e('input', {type: 'text', value: url,
			 onChange: handleChangeUrl})),
	   e('button', {onClick: handleClick}, 'Add picture'))
}
