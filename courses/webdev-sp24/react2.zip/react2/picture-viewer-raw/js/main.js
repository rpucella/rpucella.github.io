
const useState = React.useState
const e = React.createElement

window.onload = () => {
    const domContainer = document.querySelector('#app')
    const root = ReactDOM.createRoot(domContainer)
    root.render(e(App, {}))
}

