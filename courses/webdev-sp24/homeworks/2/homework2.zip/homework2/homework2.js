
// homework2.js
//
// Loaded by homework2.html.


function init() {
    console.log('Initializing')
}

// Call init() when homework2.html finishes loading.
window.onload = init
