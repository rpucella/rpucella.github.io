
/*

  Homework 2 (Node.js question 0)

  Please include your solutions in this file.

*/



// Do not touch this function. It's a mess, but almost a necessary one right now.
// From https://github.com/heapwolf/prompt-sync
function input(ask, value, opts) {
  const fs = require('fs')
  let term = 13 // carriage return
  let config = {}
  let sigint = false
  let eot = false
  let autocomplete = function(){return []}
  history = ''
  prompt.history = {save: function(){}}
  prompt.hide = function (ask) { return prompt(ask, {echo: ''}) }
  return prompt(ask, value, opts)

  function prompt(ask, value, opts) {
    let insert = 0, savedinsert = 0, res, i, savedstr
    opts = opts || {}
    if (Object(ask) === ask) {
      opts = ask
      ask = opts.ask
    } else if (Object(value) === value) {
      opts = value
      value = opts.value
    }
    ask = ask || ''
    let echo = opts.echo
    let masked = 'echo' in opts
    autocomplete = opts.autocomplete || autocomplete
    let fd = (process.platform === 'win32') ?
      process.stdin.fd :
      fs.openSync('/dev/tty', 'rs')
    let wasRaw = process.stdin.isRaw
    if (!wasRaw) { process.stdin.setRawMode && process.stdin.setRawMode(true) }
    let buf = Buffer.alloc(3)
    let str = '', character, read
    savedstr = ''
    if (ask) {
      process.stdout.write(ask)
    }
    let cycle = 0
    let prevComplete
    while (true) {
      read = fs.readSync(fd, buf, 0, 3)
      if (read > 1) { // received a control sequence
        switch(buf.toString()) {
          case '\u001b[A':  //up arrow
            if (masked) break
            if (!history) break
            if (history.atStart()) break

            if (history.atEnd()) {
              savedstr = str
              savedinsert = insert
            }
            str = history.prev()
            insert = str.length
            process.stdout.write('\u001b[2K\u001b[0G' + ask + str)
            break
          case '\u001b[B':  //down arrow
            if (masked) break
            if (!history) break
            if (history.pastEnd()) break

            if (history.atPenultimate()) {
              str = savedstr
              insert = savedinsert
              history.next()
            } else {
              str = history.next()
              insert = str.length
            }
            process.stdout.write('\u001b[2K\u001b[0G'+ ask + str + '\u001b['+(insert+ask.length+1)+'G')
            break
          case '\u001b[D': //left arrow
            if (masked) break
            let before = insert
            insert = (--insert < 0) ? 0 : insert
            if (before - insert)
              process.stdout.write('\u001b[1D')
            break
          case '\u001b[C': //right arrow
            if (masked) break
            insert = (++insert > str.length) ? str.length : insert
            process.stdout.write('\u001b[' + (insert+ask.length+1) + 'G')
            break
          default:
            if (buf.toString()) {
              str = str + buf.toString()
              str = str.replace(/\0/g, '')
              insert = str.length
              promptPrint(masked, ask, echo, str, insert)
              process.stdout.write('\u001b[' + (insert+ask.length+1) + 'G')
              buf = Buffer.alloc(3)
            }
        }
        continue // any other 3 character sequence is ignored
      }
      // if it is not a control character seq, assume only one character is read
      character = buf[read-1]
      // catch a ^C and return null
      if (character == 3){
        process.stdout.write('^C\n')
        fs.closeSync(fd)
        if (sigint) process.exit(130)
        process.stdin.setRawMode && process.stdin.setRawMode(wasRaw)
        return null
      }
      // catch a ^D and exit
      if (character == 4) {
        if (str.length == 0 && eot) {
          process.stdout.write('exit\n')
          process.exit(0)
        }
      }
      // catch the terminating character
      if (character == term) {
        fs.closeSync(fd)
        if (!history) break
        if (!masked && str.length) history.push(str)
        history.reset()
        break
      }
      // catch a TAB and implement autocomplete
      if (character == 9) { // TAB
        res = autocomplete(str)
        if (str == res[0]) {
          res = autocomplete('')
        } else {
          prevComplete = res.length
        }
        if (res.length == 0) {
          process.stdout.write('\t')
          continue
        }
        let item = res[cycle++] || res[cycle = 0, cycle++]
        if (item) {
          process.stdout.write('\r\u001b[K' + ask + item)
          str = item
          insert = item.length
        }
      }
      if (character == 127 || (process.platform == 'win32' && character == 8)) { //backspace
        if (!insert) continue
        str = str.slice(0, insert-1) + str.slice(insert)
        insert--
        process.stdout.write('\u001b[2D')
      } else {
        if ((character < 32 ) || (character > 126))
            continue
        str = str.slice(0, insert) + String.fromCharCode(character) + str.slice(insert)
        insert++
      }
      promptPrint(masked, ask, echo, str, insert)
    }
    process.stdout.write('\n')
    process.stdin.setRawMode && process.stdin.setRawMode(wasRaw)
    return str || value || ''
  }
  function promptPrint(masked, ask, echo, str, insert) {
    if (masked) {
        process.stdout.write('\u001b[2K\u001b[0G' + ask + Array(str.length+1).join(echo))
    } else {
      process.stdout.write('\u001b[s')
      if (insert == str.length) {
          process.stdout.write('\u001b[2K\u001b[0G'+ ask + str)
      } else {
        if (ask) {
          process.stdout.write('\u001b[2K\u001b[0G'+ ask + str)
        } else {
          process.stdout.write('\u001b[2K\u001b[0G'+ str + '\u001b[' + (str.length - insert) + 'D')
        }
      }
      // Reposition the cursor to the right of the insertion point
      let askLength = ask.length
      process.stdout.write(`\u001b[${askLength+1+(echo==''? 0:insert)}G`)
    }
  }
}

function createBoard(n) {
  console.log('createBoard not implemented')
  return []
}

function run(n) {
  console.log('run not implemented')
}
