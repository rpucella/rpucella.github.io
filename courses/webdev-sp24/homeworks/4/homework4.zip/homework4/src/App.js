import { useState } from 'react'
import './App.css'

function App() {
  return (
    <div className="layout">

      <p>Replace this piece with your own game component.</p>

      <p>You can access images by putting them in the <tt>public/</tt> folder.
        For instance, image <tt>public/bird.png</tt> can be accessed using
        <tt>&lt;img src="bird.png" /&gt;</tt> like so:</p>

      <img style={{width: '200px'}} src="bird.png" />

    </div>
  )
}

export default App
