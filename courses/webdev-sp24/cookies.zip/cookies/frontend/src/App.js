import './App.css'
import {useState} from 'react'
import Selection from './Selection'
import NewPicture from './NewPicture'
import Image from './Image'
import Thumbnails from './Thumbnails'
import Preferences from './Preferences'

function App() {
  // State
  const [pics, setPics] = useState(null)
  const [current, setCurrent] = useState(0)
  const [prefs, setPrefs] = useState({})
  // Helper function to add a new picture to the state
  const getPictures = () => {
    fetch("/pictures").then(resp => resp.json().then(j => {
      setPics(j.pictures)
      // COOKIES DEMO.
      setPrefs(j.preferences)
    }))
  }
  const addPic = (name, url) => {
    const newPics = [...pics, {name: name, url:url}]
    setPics(newPics)
    setCurrent(newPics.length - 1)
  }
  if (pics === null) {
    getPictures()
    return <div>Loading...</div>
  } else {
    return (
      <div>
        <h1 className="title">React Demo</h1>
        <div className="layout">
          <div className="left-column">
            <Selection pics={pics} current={current} setCurrent={setCurrent} />
            <NewPicture addPic={addPic} />
            <Preferences prefs={prefs} getPictures={getPictures} />
          </div>
          <div className="right-column">
            <Image pic={pics[current]} />
            <Thumbnails pics={pics} current={current} setCurrent={setCurrent} />
          </div>
        </div>
      </div>
    )
  }
}

export default App
