from flask import Flask, send_from_directory, request, redirect, make_response
from dbs.pictures_fs import AvailablePictures

app = Flask(__name__, static_folder=None)

BUILD_FOLDER = 'frontend/build'

PICTURES = AvailablePictures()

@app.route("/")
def get_root():
    return redirect("/index.html")

@app.route("/pictures")
def get_pictures():
    preferences_cookie = request.cookies.get("pv_preferences")
    if preferences_cookie:
        alpha = preferences_cookie == "true"
    else:
        alpha = False
    pics = PICTURES.get_pictures()
    if alpha:
        pics = sorted(pics, key=lambda r:r['name'])
    return add_cookie({
        'pictures': pics,
        'preferences': {
            'alpha': alpha
        }
    }, "pv_preferences", "true" if alpha else "false")

@app.route("/add-picture", methods=["POST"])
def addPicture():
    body = request.json
    ##print(body)
    PICTURES.add_picture(body['name'], body['url'])
    return "ok"

@app.route("/set-preferences", methods=["POST"])
def setPreferences():
    body = request.json
    if 'alpha' in body:
        alpha = body['alpha']
    else:
        alpha = False
    return add_cookie("ok", "pv_preferences", "true" if alpha else "false")

@app.route("/<path:p>")
def serveFile(p):
    ##print(f"asking for file {p}")
    return send_from_directory(BUILD_FOLDER, p)

def add_cookie(result, name, value):
    # adds a Set-Cookie: <name>=<value> header to a response
    resp = make_response(result)
    resp.set_cookie(name, value)
    return resp
