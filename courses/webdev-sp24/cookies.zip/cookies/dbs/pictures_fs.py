import csv

# FILE SYSTEM STORAGE (CSV FILE)

_FILE = 'pictures.csv'

class AvailablePictures:

    def __init__(self):
        pass

    def get_pictures(self):
        with open(_FILE, 'rt') as fp:
            csvr = csv.reader(fp, delimiter='\t')
            return [{'name': r[0], 'url': r[1]} for r in csvr]

    def add_picture(self, name, url):
        with open(_FILE, 'at') as fp:
            csvw = csv.writer(fp, delimiter='\t')
            csvw.writerow([name, url])
