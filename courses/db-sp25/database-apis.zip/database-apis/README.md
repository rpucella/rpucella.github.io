
Requires Python 3

## To install:

0. Start a terminal in the folder `database-apis`

1. Create a virtual environment:

        python3 -m venv venv
    
2. Activate the virtual environment

        . ./venv/bin/activate
    
3. Install flask and sqlalchemy

        pip install flask
        pip install sqlalchemy

4. Run the web application server:

        flask run
        
5. Navigate your browser to `http://localhost:5000` (or whatever `flask run` tells you to use).

6. If you want to switch to the ORM instead of the direct connection to the data, edit `app.py` and see the comment at the top of the file in the imports section. You will need to stop the web application server you started in step 4, and restart it again for the change to take effect.

