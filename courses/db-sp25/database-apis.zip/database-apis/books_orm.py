from typing import List
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, ForeignKey, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

engine = create_engine('sqlite:///books.db')

Base = declarative_base()

class Books(Base):
    __tablename__ = 'Books'
    isbn = Column(String, primary_key=True)
    title = Column(String)
    year = Column(Integer)

class Authors(Base):
    __tablename__ = 'Authors'
    authorId = Column(Integer, primary_key=True)
    name = Column(String)

class Write(Base):
    __tablename__ = 'Write'
    isbn = Column(String, ForeignKey("Books.isbn"), primary_key=True)
    authorId = Column(Integer, ForeignKey("Authors.authorId"), primary_key=True)


from sqlalchemy.orm import sessionmaker

Session = sessionmaker(bind=engine)
session = Session()

def get_books():
    books = (session
             .query(Books.isbn, Books.title, Books.year, Authors.name)
             .select_from(Books)
             .join(Write)
             .join(Authors)
             .all())
    return [{"isbn": b.isbn, "title": b.title, "year": b.year, "name": b.name} for b in books]

def get_grouped_books():
    books = (session
             .query(Books.isbn, Books.title, Books.year, func.group_concat(Authors.name, ",").label('name'))
             .select_from(Books)
             .join(Write)
             .join(Authors)
             .group_by(Books.isbn, Books.title, Books.year)
             .all())
    return [{"isbn": b.isbn, "title": b.title, "year": b.year, "name": b.name} for b in books]

def get_books_year(year):
    books = (session
             .query(Books.isbn, Books.title, Books.year, Authors.name)
             .select_from(Books)
             .join(Write)
             .join(Authors)
             .filter(Books.year == year)
             .all())
    return [{"isbn": b.isbn, "title": b.title, "year": b.year, "name": b.name} for b in books]
