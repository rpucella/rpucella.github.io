import sqlite3

# DIRECT RELATIONAL DATABASE

_DBNAME = 'books.db'

def get_books():
    conn = sqlite3.connect(_DBNAME)
    curs = conn.cursor()
    curs.execute("""
        select Books.isbn, Books.title, Books.year, Authors.name
        from Books
        join Write on Books.isbn = Write.isbn
        join Authors on Authors.authorId = Write.authorId
        order by Books.title
    """)
    rows = curs.fetchall()
    conn.close()
    return [{"isbn": r[0], "title": r[1], "year": r[2], "name": r[3]} for r in rows]


def get_grouped_books():
    conn = sqlite3.connect(_DBNAME)
    curs = conn.cursor()
    curs.execute("""
        select Books.isbn, Books.title, Books.year, group_concat(Authors.name, ', ')
        from Books
        join Write on Books.isbn = Write.isbn
        join Authors on Authors.authorId = Write.authorId
        group by Books.isbn, Books.title, Books.year
        order by Books.title
    """)
    rows = curs.fetchall()
    conn.close()
    return [{"isbn": r[0], "title": r[1], "year": r[2], "name": r[3]} for r in rows]

def get_books_year(year):
    conn = sqlite3.connect(_DBNAME)
    curs = conn.cursor()
    curs.execute(f"""
        select Books.isbn, Books.title, Books.year, Authors.name
        from Books
        join Write on Books.isbn = Write.isbn
        join Authors on Authors.authorId = Write.authorId
        where year = ?
        order by Books.title
    """, [year])
    rows = curs.fetchall()
    conn.close()
    return [{"isbn": r[0], "title": r[1], "year": r[2], "name": r[3]} for r in rows]
