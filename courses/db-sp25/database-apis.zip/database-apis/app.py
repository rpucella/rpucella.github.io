from flask import Flask, send_from_directory, request, redirect

# Uncomment ONE of the following two lines to use either
# the direct connection to the data or the ORM connection.
import books_direct as books
#import books_orm as books

app = Flask(__name__, static_folder=None)

BUILD_FOLDER = 'frontend/'

@app.route("/")
def get_root():
    return redirect("/index.html")

@app.route("/api/books")
def get_books():
    rows = books.get_books()
    return {"rows": rows}

@app.route("/api/grouped-books")
def get_grouped_books():
    rows = books.get_grouped_books()
    return {"rows": rows}

@app.route("/api/books-year")
def get_books_year():
    year = request.args['y']
    rows = books.get_books_year(year)
    return {"rows": rows}

@app.route("/<path:p>")
def serveFile(p):
    ##print(f"asking for file {p}")
    return send_from_directory(BUILD_FOLDER, p)
