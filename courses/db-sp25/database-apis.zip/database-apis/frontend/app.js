
window.onload = main

async function main() {
    console.log("Initializing")
    await fetch_books("/api/books")
}

function clear_table() {
    const tbl = document.getElementById("t")
    while (tbl.firstChild) {
        tbl.removeChild(tbl.firstChild)
    }
}

function fill_table(rows) {
    clear_table()
    const tbl = document.getElementById("t")
    //console.dir(data, {depth:null})
    for (const r of rows) {
        const tr = document.createElement("tr")
        for (const f of ['isbn', 'title', 'year', 'name']) {
            const td = document.createElement("td")
            td.innerText = r[f]
            tr.appendChild(td)
        }
        tbl.appendChild(tr)
    }
}

async function fetch_books(endpoint) {
    const response = await fetch(endpoint)
    const data = await response.json()
    fill_table(data.rows)
}

async function click_books() {
    fetch_books("/api/books")
}

async function click_grouped_books() {
    fetch_books("/api/grouped-books")
}

async function click_books_year() {
    const year = document.getElementById('year').value
    fetch_books(`/api/books-year?y=${year}`)
}
