
import scala.math._


class Point (val x:Double, val y:Double) { 
  override def toString = "(" + x.toString + "," + y.toString + ")"
}


abstract class Shape {

  def area : Double

  def boundingBox : Rectangle

  def perimeter : Double

  def toString : String

}


class Circle (c:Point, r:Double) extends Shape {

  def area = Pi * r * r

  def boundingBox = 
    new Rectangle (new Point (c.x-r,c.y-r), new Point (c.x+r,c.y+r))

  def perimeter = 2 * Pi * r

  override def toString = "Circle " + c.toString + " " + r.toString
}


class Rectangle (p1:Point, p2:Point) extends Shape {

  def area = abs ((p2.x-p1.x) * (p2.y-p1.y))

  def boundingBox = this

  def perimeter = 2 * abs ((p2.x-p1.x) + (p2.y-p1.y))

  override def toString = "Rectangle " + p1.toString + " " + p2.toString

}


class Triangle (p1:Point, p2:Point, p3:Point) extends Shape {

  def min3 (a:Double,b:Double,c:Double) = min(min(a,b),c)

  def max3 (a:Double,b:Double,c:Double) = max(max(a,b),c)

  def dist (p1:Point,p2:Point) = sqrt ((p2.x-p1.x)*(p2.x-p1.x)+(p2.y-p1.y)*(p2.y-p1.y))

  def area = abs ((p1.x*(p2.y-p3.y) + p2.x*(p3.y-p1.y) + p3.x*(p1.y-p2.y))/2)

  def boundingBox = new Rectangle (new Point (min3 (p1.x,p2.x,p3.x),
                                              min3 (p1.y,p2.y,p3.y)),
                                   new Point (max3 (p1.x,p2.x,p3.x),
                                              max3 (p1.y,p2.y,p3.y)))

  def perimeter = dist (p1,p2) + dist (p2,p3) + dist (p3,p1)

  override def toString = "Triangle " + p1.toString + " " + p2.toString + " " + p3.toString + " "

}
