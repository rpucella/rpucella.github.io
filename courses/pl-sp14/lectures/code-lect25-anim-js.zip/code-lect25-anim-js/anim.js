
/*   A simple animation DSL 
 *
 */

window.requestAnimationFrame = 
    window.requestAnimationFrame || window.mozRequestAnimationFrame ||
    window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;


function abort (msg) {
    alert (msg);
    throw { name: 'FatalError', message: msg }; 
}


/*
 *     INTERNAL REPRESENTATION
 */


/*
 *     Values 
 */

function VBool (b) {
  this.bool = b;
  this.toString = function () { return (this.bool? "true" : "false"); }
  this.isFloat = false;
  this.isBool = true;
  this.isFrame = false;
  this.isBehavior = false;
  this.if = function (env,eThen,eElse) {
      if (this.bool) {
	  return eThen.eval (env);
      } else {
	  return eElse.eval (env);
      }
  }
}

function VFloat (f) {
  this.float = f;
  this.toString = function () { return ''+f; }
  this.isFloat = true;
  this.isBool = false;
  this.isFrame = false;
  this.isBehavior = false;
}

function VClosure (name,param,expr,env) {
  this.name = name;
  this.param = param;
  this.expr = expr;
  this.env = env;
  this.toString = function () { return "<closure>"; }
  this.apply = function (value) {
      if (this.name == null) {
	  var newEnv = this.env.add ([this.param,value]);
	  return this.expr.eval (newEnv);
      } else {
	  var newEnv = this.env.add ([this.param,value,this.name,this]);
	  return this.expr.eval (newEnv);
      }
  }
  this.isFloat = false;
  this.isBool = false;
  this.isFrame = false;
  this.isBehavior = false;
}

function VFrame (arr) {
    function clear (ctx) {
	var fillStyle = ctx.fillStyle;
	ctx.fillStyle = "#ffffff";
	ctx.fillRect(0,0,500,500);	
	ctx.fillStyle = fillStyle;
    }
    this.frame = arr;
    this.toString = function () { return "<frame>"; }
    this.overlay = function (arr) { 
	return new VFrame (this.frame.concat (arr)); 
    }
    this.moveTo = function (x,y) {
	var arr = new Array (this.frame.length);
	for (var i = 0; i<this.frame.length; i += 3) {
	    arr[i] = this.frame[i] + x;
	    arr[i+1] = this.frame[i+1] + y;
	    arr[i+2] = this.frame[i+2];
	}
	return new VFrame (arr);
    }
    this.draw = function (ctx) {
	clear (ctx);
	for (var i = 0; i<this.frame.length; i += 3) {
	    ctx.beginPath();
	    ctx.arc(250+this.frame[i],250-this.frame[i+1],this.frame[i+2],0,2*Math.PI);
	    ctx.fill();
	}
    }
    this.isFloat = false;
    this.isBool = false;
    this.isFrame = true;
    this.isBehavior = false;
}


function VBehavior (behavior) {
  this.behavior = behavior;
  this.isFloat = false;
  this.isBool = false;
  this.isFrame = false;
  this.at = function (t) {
      return this.behavior (t);
  }
  this.draw = function (ctx) {
      var time = 0;
      var behavior = this.behavior;
      function next (timestamp) {
	  if (time < 10) {
	      (behavior (time)).draw (ctx);
	      time += 0.01;
	      window.requestAnimationFrame (next);
	  }
      }
      window.requestAnimationFrame (next);
  }
  this.isBehavior = true;
  this.toString = function () { return "<behavior " + this.at (0) + ">"; }
  this.if = function (env,eThen,eElse) { 
	  var me = this
	  return new VBehavior (function (t) {
		  var v = (me.at(t)).if (env,new EBehaviorAt (eThen,t),
					 new EBehaviorAt (eElse,t));
		      return v;
	  });
      }
}



/*
 *     Expressions
 */

function EVal (value) {
    this.value = value;
    this.eval = function (env) {
	return this.value;
    }
    this.toString = function () { return this.value.toString (); }
}

function EIdent (name) {
    this.name = name;
    this.eval = function (env) {
	return env.lookup (this.name);
    }
    this.toString = function () { return "EIdent (" + this.name + ")"; }
}

function ELet (name,expr1,expr2) {
    this.name = name;
    this.expr1 = expr1;
    this.expr2 = expr2;
    this.eval = function (env) {
	var newEnv = env.add ([this.name, this.expr1.eval (env)]);
	return this.expr2.eval (newEnv);
    }
    this.toString = function () { return ("ELet (" + this.name + "," + 
					  this.expr1.toString () + "," + 
					  this.expr2.toString () + ")"); }
}

function ELetFun (name,param,expr1,expr2) {
    this.name = name;
    this.param = param;
    this.expr1 = expr1;
    this.expr2 = expr2;
    this.eval = function (env) {
	var closure = new VClosure (this.name,this.param,this.expr1,env);
	var newEnv = env.add ([this.name,closure]);
	return this.expr2.eval (newEnv);
    }
    this.toString = function () { return ("ELetFun (" + this.name + "," + 
					  this.param + "," + 
					  this.expr1.toString() + "," + 
					  this.expr2.toString() + ")"); }
}

function EFun (name,expr) {
    this.name = name;
    this.expr = expr;
    this.eval = function (env) {
	return new VClosure (null,this.name,this.expr,env);
    }
    this.toString = function () { return ("EFun (" + this.name + "," + 
					  this.expr.toString () + ")"); }
}

function EApp (expr1,expr2) {
    this.expr1 = expr1;
    this.expr2 = expr2;
    this.eval = function (env) {
	var v1 = this.expr1.eval (env);
	var v2 = this.expr2.eval (env);
	return v1.apply (v2);
    }
    this.toString = function () { return ("EApp (" + this.expr1.toString() + "," + 
					  this.expr2.toString() + ")"); }
}

function EIf (expr1, expr2, expr3) {
    this.expr1 = expr1;
    this.expr2 = expr2;
    this.expr3 = expr3;
    this.eval = function (env) {
	var cond = this.expr1.eval (env)
	if (cond.isBool || cond.isBehavior) {
	    return cond.if (env,this.expr2,this.expr3);
	} else {
	    abort ("conditional not a Boolean or behavior");
	}
    }
    this.toString = function () { return ("EIf (" + this.expr1.toString() + "," + 
					  this.expr2.toString() + "," + 
					  this.expr3.toString() + ")"); }
}

function EBehaviorAt (expr,t) {
    this.expr = expr;
    this.t = t;
    this.eval = function (env) {
	var v = this.expr.eval (env);
	if (v.isBehavior) {
	    return v.at(this.t);
	} else {
	    abort('EBehaviorAt not given a behavior expression');
	}
    }
    this.toString = function () { return ("EBehaviorAt (" + this.expr.toString() + 
					  "," + this.t + ")"); }
}

function EPrimCall1 (prim, expr1) {
    this.prim = prim;
    this.expr1 = expr1;
    this.eval = function (env) {
	return this.prim (this.expr1.eval (env));
    }
    this.toString = function () { return ("EPrimCall1 (<prim>," + 
					  this.expr1.toString() + ")"); }
}

function EPrimCall2 (prim, expr1, expr2) {
    this.prim = prim;
    this.expr1 = expr1;
    this.expr2 = expr2;
    this.eval = function (env) {
	return this.prim (this.expr1.eval (env), this.expr2.eval (env));
    }
    this.toString = function () { return ("EPrimCall2 (<prim>," + 
					  this.expr1.toString() + "," + 
					  this.expr2.toString() + ")"); }
}

function EPrimCall3 (prim, expr1, expr2, expr3) {
    this.prim = prim;
    this.expr1 = expr1;
    this.expr2 = expr2;
    this.expr3 = expr3;
    this.eval = function (env) {
	return this.prim (this.expr1.eval (env), this.expr2.eval (env),
			  this.expr3.eval (env));
    }
    this.toString = function () { return ("EPrimCall3 (<prim>," + 
					  this.expr1.toString() + "," + 
					  this.expr2.toString() + "," + 
					  this.expr3.toString() + ")"); }
}



/*
 *     Primitive Operations
 */

function primAdd (value1, value2) {
    if ((value1.isFloat) && (value2.isFloat)) {
	return new VFloat (value1.float + value2.float);
    } 
    if (value1.isBehavior && value2.isBehavior) {
	return new VBehavior (function (t) { return primAdd(value1.at(t),
							    value2.at(t)); });
    }
    if (value2.isBehavior) {
	return new VBehavior (function (t) { return primAdd(value1,value2.at(t)); });
    }
    if (value1.isBehavior) {
	return new VBehavior (function (t) { return primAdd(value1.at(t),value2); });
    }
    abort('type error in primAdd (' + value1.toString() + ',' + 
	  value2.toString()+')');
}

function primSub (value1, value2) {
    if ((value1.isFloat) && (value2.isFloat)) {
	return new VFloat (value1.float - value2.float);
    } 
    if (value1.isBehavior && value2.isBehavior) {
	return new VBehavior (function (t) { return primSub(value1.at(t),
							    value2.at(t)); });
    }
    if (value2.isBehavior) {
	return new VBehavior (function (t) { return primSub(value1,value2.at(t)); });
    }
    if (value1.isBehavior) {
	return new VBehavior (function (t) { return primSub(value1.at(t),value2); });
    }
    abort('type error in primSub (' + value1.toString() + ',' + 
	  value2.toString()+')');
}

function primMult (value1, value2) {
    if ((value1.isFloat) && (value2.isFloat)) {
	return new VFloat (value1.float * value2.float);
    } 
    if (value1.isBehavior && value2.isBehavior) {
	return new VBehavior (function (t) { return primMult(value1.at(t),
							    value2.at(t)); });
    }
    if (value2.isBehavior) {
	return new VBehavior (function (t) { return primMult(value1,value2.at(t)); });
    }
    if (value1.isBehavior) {
	return new VBehavior (function (t) { return primMult(value1.at(t),value2); });
    }
    abort('type error in primMult (' + value1.toString() + ',' + 
	  value2.toString()+')');
}

function primDiv (value1, value2) {
    if ((value1.isFloat) && (value2.isFloat)) {
	return new VFloat (value1.float / value2.float);
    } 
    if (value1.isBehavior && value2.isBehavior) {
	return new VBehavior (function (t) { return primDiv(value1.at(t),
							    value2.at(t)); });
    }
    if (value2.isBehavior) {
	return new VBehavior (function (t) { return primDiv(value1,value2.at(t)); });
    }
    if (value1.isBehavior) {
	return new VBehavior (function (t) { return primDiv(value1.at(t),value2); });
    }
    abort('type error in primDiv (' + value1.toString() + ',' + 
	  value2.toString()+')');
}

function primLess (value1, value2) {
    if ((value1.isFloat) && (value2.isFloat)) {
	return new VBool (value1.float < value2.float);
    } 
    if (value1.isBehavior && value2.isBehavior) {
	return new VBehavior (function (t) { return primLess(value1.at(t),
							    value2.at(t)); });
    }
    if (value2.isBehavior) {
	return new VBehavior (function (t) { return primLess(value1,value2.at(t)); });
    }
    if (value1.isBehavior) {
	return new VBehavior (function (t) { return primLess(value1.at(t),value2); });
    }
    abort('type error in primLess (' + value1.toString() + ',' + 
	  value2.toString()+')');
}

function primSin (value) {
    if (value.isFloat) {
	return new VFloat (Math.sin (value.float));
    }
    if (value.isBehavior) {
	return new VBehavior (function (t) { return primSin (value.at(t));  });
    }
    abort('type error in primSin (' + value.toString() + ')');
}

function primCos (value) {
    if (value.isFloat) {
	return new VFloat (Math.cos (value.float));
    }
    if (value.isBehavior) {
	return new VBehavior (function (t) { return primCos (value.at(t));  });
    }
    abort('type error in primCos (' + value.toString() + ')');
}

function primSprite (value) {
    if (value.isFloat) {
	return new VFrame ([0,0,value.float]);
    }
    if (value.isBehavior) {
	return vBehavior (function (t) { return primSprite (value.at(t)); });
    }
    abort('type error in primSprite (' + value.toString() + ')');
}

function primOverlay (value1,value2) {
    if (value1.isFrame && value2.isFrame) {
	return (value1.overlay (value2.frame));
    }
    if (value1.isBehavior && value2.isBehavior) {
	return vBehavior (function (t) { return primOverlay (value1.at(t),
							     value2.at(t));});
    }
    if (value2.isBehavior) {
	return new VBehavior (function (t) { 
		return primOverlay(value1,value2.at(t)); 
	});
    }
    if (value1.isBehavior) {
	return new VBehavior (function (t) { 
		return primOverlay(value1.at(t),value2); 
	});
    }
    abort('type error in primOverlay (' + value1.toString() + ',' + 
	  value2.toString()+')');
}

function primMoveTo (value1,value2,value3) {
    if (value1.isFloat & value2.isFloat && value3.isFrame) {
	return (value3.moveTo (value1.float, value2.float));
    }
    if (value1.isBehavior && value2.isBehavior && value3.isBehavior) {
	return new VBehavior (function (t) { return primMoveTo (value1.at (t),
							    value2.at (t),
							    value3.at (t)); });
    }
    if (value1.isBehavior && value2.isBehavior) {
	return new VBehavior (function (t) { 
		return primMoveTo(value1.at(t),value2.at(t),value3); 
	});
    }
    if (value1.isBehavior && value3.isBehavior) {
	return new VBehavior (function (t) { 
		return primMoveTo(value1.at(t),value2,value3.at(t)); 
	});
    }
    if (value2.isBehavior && value3.isBehavior) {
	return new VBehavior (function (t) { 
		return primMoveTo(value1,value2.at(t),value3.at(t)); 
	});
    }
    if (value1.isBehavior) {
	return new VBehavior (function (t) { 
		return primMoveTo(value1.at(t),value2,value3); 
	});
    }
    if (value2.isBehavior) {
	return new VBehavior (function (t) { 
		return primMoveTo(value1,value2.at(t),value3); 
	});
    }
    if (value3.isBehavior) {
	return new VBehavior (function (t) { 
		return primMoveTo(value1,value2,value3.at(t)); 
	});
    }
    abort('type error in primMoveTo (' + value1.toString() + ',' + 
	  value2.toString()+',' + value3.toString() + ')');
}

function primLift (value1) {
    if (value1.isBehavior) {
	return value1;
    } 
    return new VBehavior (function (t) { return value1; });
}

function primSpeed (value1, value2) {
    if (value1.isFloat && value2.isBehavior) {
	return vBehavior (function (t) { return value2.at (t * value1.float); });
    }
    abort('type error in primSpeed (' + value1.toString() + ',' + 
	  value2.toString() + ')');
}

function primDelay (value1, value2) {
    if (value1.isFloat && value2.isBehavior) {
	return vBehavior (function (t) { return value2.at (t + value1.float); });
    }
    abort('type error in primDelay (' + value1.toString() + ',' + 
	  value2.toString() + ')');
}
   
 

/*     
 *      Environments
 */

function Env (init) {
    this.entries = init;
    this.add = function (newEntries) {
	return new Env (this.entries.concat (newEntries));
    }
    this.def = function (str) {
	var res = def (str);
	if (res==null) {
	    abort ("problem in definition " +str);
	}
	var v = res[1].eval(this);
	return new Env (this.entries.concat ([res[0],v]));
    }
    this.lookup = function (name) {
	for (var i = 0; i < this.entries.length; i += 2) {
	    if (this.entries[i]==name) {
		return this.entries[i+1];
	    }
	}
	abort('environment lookup error: '+name);
    }
}




/* 
 *    In lieu of a parser, here are functions to help 
 *    construct internal representation expressions
 */

function vBehavior (b) {
    return new VBehavior (b);
}

function vClosure (n,p,expr,env) {
    return new VClosure (n,p,expr,env);
}

function eVal (v) {
    return new EVal (v);
}

function eFloat (v) {
    return new EVal (new VFloat (v));
}

function eBool (b) {
    return new EVal (new VBool (b));
}

function eIdent (n) {
    return new EIdent (n);
}

function eFun (n,e) {
    return new EFun (n,e);
}

function eLet (n,e1,e2) {
    return new ELet (n,e1,e2);
}

function eLetFun (n,p,e1,e2) {
    return new ELetFun (n,p,e1,e2);
}

function eIf (e1,e2,e3) {
    return new EIf (e1,e2,e3);
}

function eApp (e1,e2) {
    return new EApp (e1,e2);
}

function eAdd (e1,e2) {
    return new EPrimCall2 (primAdd,e1,e2);
}

function eMult (e1,e2) {
    return new EPrimCall2 (primMult,e1,e2);
}

function eSub (e1,e2) {
    return new EPrimCall2 (primSub,e1,e2);
}

function eDiv (e1,e2) {
    return new EPrimCall2 (primDiv,e1,e2);
}

function eLess (e1,e2) {
    return new EPrimCall2 (primLess,e1,e2);
}

function eSin (e1) {
    return new EPrimCall1 (primSin, e1);
}

function eCos (e1) {
    return new EPrimCall1 (primCos, e1);
}

function eSprite (e1) {
    return new EPrimCall1 (primSprite, e1);
}

function eOverlay (e1,e2) {
    return new EPrimCall2 (primOverlay, e1, e2);
}

function eMoveTo (e1,e2,e3) {
    return new EPrimCall3 (primMoveTo, e1, e2, e3);
}

function eLift (e1) {
    return new EPrimCall1 (primLift, e1);
}

function eSpeed (e1,e2) {
    return new EPrimCall2 (primSpeed, e1, e2);
}

function eDelay (e1,e2) {
    return new EPrimCall2 (primDelay, e1, e2);
}

var eTime = eVal (vBehavior (function (t) { return new VFloat (t); }));



var emptyEnv = new Env ([]);


var initEnv = new Env (["+",
			vClosure (null, "x",
				  eFun ("y", eAdd (eIdent ("x"),
						   eIdent ("y"))),
				  emptyEnv),
			"*",
			vClosure (null, "x",
				  eFun ("y", eMult (eIdent ("x"),
						    eIdent ("y"))),
				  emptyEnv),
			"-",
			vClosure (null, "x",
				  eFun ("y", eSub (eIdent ("x"),
						   eIdent ("y"))),
				  emptyEnv),
			"/",
			vClosure (null, "x",
				  eFun ("y", eDiv (eIdent ("x"),
						   eIdent ("y"))),
				  emptyEnv),
			"<",
			vClosure (null, "x",
				  eFun ("y", eLess (eIdent ("x"),
						    eIdent ("y"))),
				  emptyEnv),
			"sin",
			vClosure (null, "x",
				  eSin (eIdent ("x")),
				  emptyEnv),
			"cos",
			vClosure (null, "x",
				  eCos (eIdent ("x")),
				  emptyEnv),
			"sprite",
			vClosure (null, "x",
				  eSprite (eIdent ("x")),
				  emptyEnv),
			"&",
			vClosure (null, "x",
				  eFun ("y", eOverlay (eIdent ("x"),
						       eIdent ("y"))),
				  emptyEnv),
			"moveTo",
			vClosure (null, "x",
				  eFun ("y", 
					eFun ("z",
					      eMoveTo (eIdent ("x"),
						       eIdent ("y"),
						       eIdent ("z")))),
				  emptyEnv),
			"lift",
			vClosure (null, "x",
				  eLift (eIdent ("x")),
				  emptyEnv),
			"speed",
			vClosure (null, "x",
				  eFun ("y", eSpeed (eIdent ("x"),
						     eIdent ("y"))),
				  emptyEnv),
			"delay",
			vClosure (null, "x",
				  eFun ("y", eDelay (eIdent ("x"),
						     eIdent ("y"))),
				  emptyEnv),
			"time",
			vBehavior (function (t) { return new VFloat (t); }),
			"pi",
			new VFloat (Math.PI)
			]);





/*
 *    A Recursive-Descent Parser
 */

function tokenize (str) {
    var tokens = [ /^$/,
		   /^=$/,
		   /^&$/,
		   /^\+$/,
		   /^\*$/,
		   /^\\$/,
		   /^<$/, 
		   /^->$/,
		   /^-$/, 
		   /^[a-z][a-z0-9]*$/i, 
		   /^-?[0-9]*\.[0-9]*$/,
		   /^-?[0-9]+$/,
		   /^\($/,
		   /^\)$/,
		   /^\/$/]; 
    var symbols = ["let","in","true","false","if","then","else","def","fun"];

    for (var i = 0; i < tokens.length; i++) {
	if (tokens[i].test(str)) {
	    if (i==9) {
		for (j=0; j<symbols.length; j++) {
		    if (str==symbols[j]) {
			return j + 20;
		    }
		}
	    }
	    return i;
	}
    }
    abort('cannot tokenize '+str);
}
		   

function result (value,pos) {
    function Result (v,p) {
	this.value = v;
	this.pos = p;
    }
    return new Result (value, pos); 
}


function parse (what,str) {   // what = "expr" or "def"  // I know... I know...
    var strings = str.split (" ");
    var tokens = new Array (strings.length);
    for (var i = 0; i < strings.length; i++) {
	tokens[i] = tokenize (strings[i]);
    }
    
    function next (pos) {
	if (pos >= tokens.length) {
	    return null;
	}
	if (tokens[pos] == 0) {
	    return next(pos+1);
	}
	return result(tokens[pos],pos+1);
    }

    function expect (tk,pos) {
	var res = next (pos);
	if (res == null) return null;
	if (res.value == tk) return res;
	return null;
    }

    function expect_EQUAL (pos) {
	return expect (1,pos);
    }
    function expect_AMPERSAND (pos) {
	return expect (2,pos);
    }
    function expect_PLUS (pos) {
	return expect (3,pos);
    }
    function expect_STAR (pos) {
	return expect (4,pos);
    }
    function expect_LESS (pos) {
	return expect (6,pos);
    }
    function expect_ARROW (pos) {
	return expect (7,pos);
    }
    function expect_MINUS (pos) {
	return expect (8,pos);
    }
    function expect_SYM (pos) {
	var res = expect (9,pos);
	if (res == null) return null;
	return result(strings[pos],res.pos);
    }
    function expect_FLOAT (pos) {
	var res = expect (10,pos);
	if (res == null) return null;
	return result(parseFloat(strings[pos]),res.pos);
    }
    function expect_INT (pos) {
	var res = expect (11,pos);
	if (res == null) return null;
	return result(parseFloat(strings[pos]),res.pos);
    }
    function expect_LPAREN (pos) {
	return expect (12,pos);
    }
    function expect_RPAREN (pos) {
	return expect (13,pos);
    }    
    function expect_SLASH (pos) {
	return expect (14,pos);
    }

    function expect_LET (pos) {
	return expect (20,pos);
    }    
    function expect_IN (pos) {
	return expect (21,pos);
    }    
    function expect_TRUE (pos) {
	return expect (22,pos);
    }    
    function expect_FALSE (pos) {
	return expect (23,pos);
    }    
    function expect_IF (pos) {
	return expect (24,pos);
    }    
    function expect_THEN (pos) {
	return expect (25,pos);
    }    
    function expect_ELSE (pos) {
	return expect (26,pos);
    }    
    function expect_DEF (pos) {
	return expect (27,pos);
    }    
    function expect_FUN (pos) {
	return expect (28,pos);
    }    

    function choose (parsers,pos) { 
	for (var i = 0; i < parsers.length; i++) {
	    var res = parsers[i] (pos);
	    if (res != null) {
		return res;
	    }
	}
	return null;
    }

    function parse_expr (pos) {
	var res1 = parse_eterm (pos);
	if (res1 == null) return null;
	var res2 = expect_LESS (res1.pos);
	if (res2 == null) return res1;
	var res3 = parse_eterm (res2.pos);
	if (res3 == null) return null;
	return result(eApp(eApp(eIdent("<"),res1.value),res3.value),res3.pos);
    }

    function parse_eterm (pos) {
	var res1 = parse_cterm (pos);
	if (res1 == null) return null;
	var res2 = expect_AMPERSAND (res1.pos);
	if (res2 == null) return res1;
	var res3 = parse_eterm (res2.pos);
	if (res3 == null) return null;
	return result(eApp(eApp(eIdent("&"),res1.value),res3.value),res3.pos);
    }

    function parse_cterm (pos) {
	var res1 = parse_term (pos);
	if (res1 == null) return null;
	var res2 = expect_PLUS (res1.pos);
	if (res2 == null) {
	    var res2 = expect_MINUS (res1.pos);
	    if (res2 == null) return res1;
	    var res3 = parse_cterm (res2.pos);
	    return result(eApp(eApp(eIdent("-"),res1.value),res3.value),res3.pos);
	}
	var res3 = parse_cterm (res2.pos);
	return result(eApp(eApp(eIdent("+"),res1.value),res3.value),res3.pos);
    }

    function parse_term (pos) {
	var res1 = parse_factor (pos);
	if (res1 == null) return null;
	var res2 = expect_STAR (res1.pos);
	if (res2 == null) {
	    var res2 = expect_SLASH (res1.pos);
	    if (res2 == null) return res1;
	    var res3 = parse_term (res2.pos);
	    return result(eApp(eApp(eIdent("/"),res1.value),res3.value),res3.pos);
	}
	var res3 = parse_term (res2.pos);
	return result(eApp(eApp(eIdent("*"),res1.value),res3.value),res3.pos);
    }

    function parse_factor (pos) {
	var res1 = parse_aterm (pos);
	if (res1 == null) return null;
	var res2 = parse_aterm_list (res1.value,res1.pos);
	if (res2 == null) return null;
	return res2;
    }
    
    function parse_aterm (pos) {
	function aterm_INT (pos) {
	    var res1 = expect_INT (pos);
	    if (res1 == null) return null;
	    return result(eFloat(res1.value),res1.pos);
	}
	function aterm_FLOAT (pos) {
	    var res1 = expect_FLOAT (pos);
	    if (res1 == null) return null;
	    return result(eFloat(res1.value),res1.pos);
	}
	function aterm_TRUE (pos) {
	    var res1 = expect_TRUE (pos);
	    if (res1 == null) return null;
	    return result(eBool(true),res1.pos);
	}
	function aterm_FALSE (pos) {
	    var res1 = expect_FALSE (pos);
	    if (res1 == null) return null;
	    return result(eBool(false),res1.pos);
	}
	function aterm_FUN (pos) {
	    var res1 = expect_FUN (pos);
	    if (res1 == null) return null;
	    var res2 = expect_SYM (res1.pos);
	    if (res2 == null) return null;
	    var res3 = expect_ARROW (res2.pos);
	    if (res3 == null) return null;
	    var res4 = parse_expr (res3.pos);
	    if (res4 == null) return null;
	    return result(eFun(res2.value,res4.value),res4.pos);
	}
	function aterm_IF (pos) {
	    var res1 = expect_IF (pos);
	    if (res1==null) return null;
	    var res2 = parse_expr (res1.pos);
	    if (res2==null) return null;
	    var res3 = expect_THEN (res2.pos);
	    if (res3==null) return null;
	    var res4 = parse_expr (res3.pos);
	    if (res4==null) return null;
	    var res5 = expect_ELSE (res4.pos);
	    if (res5==null) return null;
	    var res6 = parse_expr (res5.pos);
	    if (res6==null) return null;
	    return result(eIf(res2.value,res4.value,res6.value),res6.pos);
	}
	function aterm_LET (pos) {
	    var res1 = expect_LET (pos);
	    if (res1==null) return null;
	    var res2 = expect_SYM (res1.pos);
	    if (res2==null) return null;
	    var res3 = expect_EQUAL (res2.pos);
	    if (res3==null) return null;
	    var res4 = parse_expr (res3.pos);
	    if (res4==null) return null;
	    var res5 = expect_IN (res4.pos);
	    if (res5==null) return null;
	    var res6 = parse_expr (res5.pos);
	    if (res6==null) return null;
	    return result(eLet(res2.value,res4.value,res6.value),res6.pos);
	}
	function aterm_LETFUN (pos) {
	    var res1 = expect_LET (pos);
	    if (res1==null) return null;
	    var res2 = expect_SYM (res1.pos);
	    if (res2==null) return null;
	    var res3 = expect_SYM (res2.pos);
	    if (res3==null) return null;
	    var res4 = parse_sym_list (function (e) { return e; }, res3.pos);
	    if (res4==null) return null;
	    var res5 = expect_EQUAL (res4.pos);
	    if (res5==null) return null;
	    var res6 = parse_expr (res5.pos);
	    if (res6==null) return null;
	    var res7 = expect_IN (res6.pos);
	    if (res7==null) return null;
	    var res8 = parse_expr (res7.pos);
	    if (res8==null) return null;
	    return result(eLetFun(res2.value,
				  res3.value,
				  res4.value(res6.value),
				  res8.value),res8.pos);
	}
	function aterm_SYM (pos) {
	    var res1 = expect_SYM (pos);
	    if (res1==null) return null;
	    return result(eIdent(res1.value),res1.pos);
	}
	function aterm_PARENS (pos) {
	    var res1 = expect_LPAREN (pos);
	    if (res1==null) return null;
	    var res2 = parse_expr (res1.pos);
	    if (res2==null) return null;
	    var res3 = expect_RPAREN (res2.pos);
	    if (res3==null) return null;
	    return result(res2.value,res3.pos);
	}

	return choose ([aterm_INT, 
			aterm_FLOAT,
			aterm_TRUE,
			aterm_FALSE,
			aterm_FUN,
			aterm_IF,
			aterm_LET,
			aterm_LETFUN,
			aterm_SYM,
			aterm_PARENS
		       ],pos);
    }

    function parse_aterm_list (at,pos) {
	var res1 = parse_aterm (pos);
	if (res1==null) return result(at,pos);
	var res2 = parse_aterm_list (eApp(at,res1.value),res1.pos);
	return res2;
    }

    function parse_sym_list (f,pos) {
	var res1 = expect_SYM (pos);
	if (res1==null) return result(f,pos);
	var res2 = parse_sym_list (function (e) { return f(eFun(res1.value,e)); },
				   res1.pos);
	return res2;
    }

    function parse_def (pos) {
	function def_fun (pos) {
	    var res2 = expect_SYM (pos);
	    if (res2==null) return null;
	    var res3 = expect_SYM (res2.pos);
	    if (res3==null) return null;
	    var res4 = parse_sym_list (function (e) { return e; }, res3.pos);
	    if (res4==null) return null;
	    var res5 = expect_EQUAL (res4.pos);
	    if (res5==null) return null;
	    var res6 = parse_expr (res5.pos);
	    if (res6==null) return null;
	    return result([res2.value,
			   eLetFun(res2.value,
				   res3.value,
				   res4.value(res6.value),
				   eIdent (res2.value))],res6.pos);
	}
	function def_val (pos) {
	    var res2 = expect_SYM (pos);
	    if (res2==null) return null;
	    var res5 = expect_EQUAL (res2.pos);
	    if (res5==null) return null;
	    var res6 = parse_expr (res5.pos);
	    if (res6==null) return null;
	    return result([res2.value,res6.value],res6.pos);
	}
	return choose ([def_fun,def_val],pos);
    }

    var res1 = (what=='expr' ? parse_expr (0) : parse_def (0));

    if (res1 == null) {
	abort('cannot parse: ' + str);
    }

    return res1.value;

}


function expr (str) {
    return parse ("expr", str);
}

function def (str) {
    return parse ("def", str);
}
