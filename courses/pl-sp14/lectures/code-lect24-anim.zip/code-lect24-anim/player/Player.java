
import java.awt.Canvas; 
import java.awt.Graphics; 
import java.awt.*; 
import java.awt.event.*; 
import java.util.*;
import java.net.*;
import java.io.*;


public class Player {


    private static class Sprite {
	public int x;
	public int y;
	public int radius;
	public Sprite (int xx1, int yy1, int rad) {
	    x=xx1; 
	    y=yy1; 
	    radius=rad;
	}
    }	
    

    private static class CanvasRegion extends Canvas { 
	public Sprite[] sprites = null;
	public int size = 500;
	public CanvasRegion() {  
	    setSize(size, size); 
	} 


	public void paint(Graphics g) { 
	    int half = size / 2;
	    g.drawLine (half,0,half,size);
	    g.drawLine (0,half,size,half);
	    if (sprites != null) {
		for (Sprite s : sprites) {
		    // g.drawRect (half + s.x - s.radius, half - s.y + s.radius,
		    // s.radius * 2, s.radius * 2);
		    g.fillOval (half + s.x - s.radius, half - s.y - s.radius,
				s.radius * 2, s.radius * 2);
		}
	    }
	}
    }


    private static class CanvasFrame extends Frame { 
	private CanvasRegion region;
	
        public void drawSprites (Sprite[] sp) {
	    this.region.sprites = sp;
	}
	
	public void clear () {
	    this.region.sprites = null;
	    this.region.repaint();
	}
	
	public void update () {
	    this.region.repaint();
	}
	
	public CanvasFrame () { 
	    super("Animation Canvas"); 
	    // add a demo component to this frame 
	    region = new CanvasRegion(); 
	    setSize(region.size+50, region.size+50); 
	    add(region); 
	    addWindowListener(new WindowAdapter() { 
		    public void windowClosing(WindowEvent e) { 
			setVisible(false); dispose(); 
			System.exit(0); 
		    } 
		});
	}
    }
    
    static public CanvasFrame canvasFrame = null;
    
    static public void initialize () {
	canvasFrame = new CanvasFrame();
	canvasFrame.setVisible(true); 
    }
    
    
    public static void draw (String frameDescr) {
	String[] entries = frameDescr.split("\\s+");
	int size = Integer.parseInt (entries[0]);

	Sprite[] sprites = new Sprite[size];

	for (int i = 0, j = 1; i < size;  i++) {
	    sprites [i] = new Sprite (Integer.parseInt(entries[j++]),
				      Integer.parseInt(entries[j++]),
				      Integer.parseInt(entries[j++]));
	}
	// System.out.print ("\n");
	// System.out.print ("clearing\n");
	// canvasFrame.clear();
	// System.out.print ("drawing\n");
	canvasFrame.drawSprites (sprites);
	// System.out.print ("updating\n");
	canvasFrame.update();
    }
    
    
    public static void sleep (int time) {
	try {Thread.sleep(time);} catch (Exception e) {};
    }



    public static void main (String[] argv) throws IOException {

	Player.initialize ();

	int port = 8040;

	int slowdown = 10;

	if (argv.length != 0) {
	    // port = Integer.parseInt (argv[0]);
	    slowdown = Integer.parseInt (argv[0]);
	}


        ServSocket serverSocket = ServSocket.create(port);
	System.out.println("Listening");
        ChanSocket clientSocket = serverSocket.accept();
	System.out.println("Connection accepted");
	while (true) {
	    String input = clientSocket.in().readLine();
	    if (input==null)
		break;
	    Player.draw (input);
	    sleep (slowdown);
	}

        clientSocket.close();
        serverSocket.close();
    }
}

