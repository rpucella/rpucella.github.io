
To start the Animation Player:

  java Player    (in the code-lect24-anim\player directory)


The Animation Player needs to already be running when you start the shell. 

If you quit the shell, you should also quit the Animation Player--a
new instance of the shell will be unable to connect to an Animation
Player that was used for a previous shell.

The core language is func (with higher-order and curried functions)

Here are the primitive operations defined by anim:

 Arithmetic +, -, *, /, <

 pi

 sin <float>
 cos <float>

 time
 at <behavior> <float>
  
 sprite <float>
 move <float> <float> <frame>
 <frame> & <frame>

 speed <float> <frame>
 delay <float> <frame>

 run <frame>

All operations lift their arguments to behaviors when needed.


Sample orbit behavior:

  def orbit r = move (r * sin (pi * time)) (r * cos (pi * time))

A simple orbiting animation:

  run (orbit 200 (sprite 10))

A more complex orbiting animation:

  run (orbit 150 (sprite 10 & speed ~3 (orbit 50 (sprite 5))))

A still more complex orbiting animation: 

  def elliptic r1 r2 = move (r1 * sin (pi * time)) (r2 * cos (pi * time))

  def moon1 = elliptic 60 30 (sprite 5)

  def moon2 = elliptic 30 60 (sprite 5)

  run (sprite 10 & speed ~2 (moon1 & moon2))

  run (orbit 150 (sprite 10 & speed ~2 (moon1 & moon2)))
