# Simple example of a game framework derived from our initial
# implementation of 2048

# for v3

def run (initF, printF, doneF, inputF, updateF, winningF):
    board = initF()

    printF(board)

    while not doneF(board):
        move = inputF(board)
        board = updateF(board,move)
        printF(board)


    if winningF(board):
        print 'Congratulations!\n'
    else:
        print 'Ouch. Sorry about that...\n'


# for v4 

def run_obj (g):
    board = g.initF()

    g.printF(board)

    while not g.doneF(board):
        move = g.inputF(board)
        board = g.updateF(board,move)
        g.printF(board)


    if g.winningF(board):
        print 'Congratulations!\n'
    else:
        print 'Ouch. Sorry about that...\n'


# for v5

class Game:

    def run (self):
        board = self.initF()

        self.printF(board)

        while not self.doneF(board):
            move = self.inputF(board)
            board = self.updateF(board,move)
            self.printF(board)


        if self.winningF(board):
            print 'Congratulations!\n'
        else:
            print 'Ouch. Sorry about that...\n'
