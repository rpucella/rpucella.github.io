
class Clock (object):

    def __init__ (self,time):
        pass

    # FIX ME
