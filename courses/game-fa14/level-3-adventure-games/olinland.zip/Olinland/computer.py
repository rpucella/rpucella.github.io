from thing import *


class Computer (Thing):
    def __init__ (self,name,loc):
        Thing.__init__(self,name,loc)

    # FIX ME
