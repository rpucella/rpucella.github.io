#
# MAZE Server
# 

# PROTOCOL:
#  -server sends LEVEL_WIDTH * LEVEL_HEIGHT map
#  -server sends "(x,y),(x,y),(x,y),(x,y)." 
#    (the position of the player and the baddies)
#  -player sends move as a direction string or "" if no move
#  -server responds "won.", "lost.", or "(x,y),(x,y),..." (as above)
#  -after sending won/lost, the server awaits for a last move message
#    as an ACK


import time
import random
import socket
import sys

from ast import literal_eval as make_tuple

LEVEL_WIDTH = 20
LEVEL_HEIGHT = 20    


# This section below is essentially lifted from maze.py, except with
# some tweaks like Eventable to make things prettier, 
# and removing all reference to drawing to a screen, since
# the server has no notion of a screen to draw to.

class Eventable (object):
    def enqueue (self,q,freq):
        self._freq = freq
        q.enqueue(freq,self)
        return self

    def requeue (self,q):
        q.enqueue(self._freq,self)
        return self

    def event (self,q):
        pass


def cell (level,x,y):
    return level[x+(y*LEVEL_WIDTH)]


class Character (Eventable):
    def __init__ (self,pic,x,y,sock,level):
        self._sock = sock
        self._x = x
        self._y = y
        self._level = level

    def position (self):
        return (self._x, self._y)

    def at_exit (self):
        return (self._y == 0)

    # returns True if the move is allowed, False otherwise
    def move (self,dx,dy):
        tx = self._x + dx
        ty = self._y + dy
        if tx >= 0 and ty >= 0 and tx < LEVEL_WIDTH and ty < LEVEL_HEIGHT:
            if cell(self._level,tx,ty) == 0:
                self._x = tx
                self._y = ty
                return True
            return False
        return False


class Player (Character):
    def __init__ (self,x,y,sock,level):
        Character.__init__(self,'android.gif',x,y,sock,level)


class Baddie (Character):
    def __init__ (self,x,y,sock,level,player):
        Character.__init__(self,'red.gif',x,y,sock,level)
        self._player = player

    def _move_toward (self,pos):
        (x,y) = pos
        result = []
        orig = (x-self._x)**2 + (y-self._y)**2
        for (dx,dy) in [(1,0),(0,1),(-1,0),(0,-1)]:
            tx, ty = self._x + dx, self._y + dy
            if tx >= 0 and ty >=0 and tx < LEVEL_WIDTH and ty < LEVEL_HEIGHT:
                dest = (tx-self._x)**2  + (ty-self._y)**2
                if dest < orig:
                    result.extend([(dx,dy)] * 3)
                else:
                    result.append((dx,dy))
        return random.choice(result)

    def event (self,q):
        if self._player.position () == (self._x,self._y):
            lost(self._sock)
        (dx,dy) = self._move_toward(self._player.position())
        self.move(dx,dy)
        self.requeue(q)


# when a game is lost or won, inform the client

def lost (sock):
    full_send(sock,"lost.")
    recv_move(sock)
    sock.close()
    exit(0)

def won (sock):
    full_send(sock,"won.")
    recv_move(sock)
    sock.close()
    exit(0)



# Create a level, just like in maze.py
#
# 0 empty
# 1 brick

def create_level ():
    screen = []
    screen.extend([1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1])
    screen.extend([1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1])
    screen.extend([1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1])
    screen.extend([1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1])
    screen.extend([1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1])
    screen.extend([1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1])
    screen.extend([1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1])
    screen.extend([1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1])
    screen.extend([1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,0,1])
    screen.extend([1,0,1,0,0,0,1,0,0,0,0,1,0,0,0,1,0,0,0,1])
    screen.extend([1,0,0,0,1,0,0,0,1,0,0,0,0,1,0,0,0,1,0,1])
    screen.extend([1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1])
    screen.extend([1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1])
    screen.extend([1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,0,1])
    screen.extend([1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1])
    screen.extend([1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1])
    screen.extend([1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1])
    screen.extend([1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1])
    screen.extend([1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1])
    screen.extend([1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1])
    return screen


# send a string on a socket 
# (keep sending until string fully sent)
def full_send (sock,msg):
    print "Sending", msg
    length = len(msg)
    totalsent = 0
    while totalsent < length:
        sent = sock.send(msg[totalsent:])
        if sent == 0:
            raise RuntimeError("socket connection broken")
        totalsent = totalsent + sent

# read a given number of characters from a socket
# (keep reading until all wanted characters received)
def full_receive (sock,length):
    chunks = []
    bytes_recd = 0
    while bytes_recd < length:
        chunk = sock.recv(min(length - bytes_recd, 2048))
        if chunk == '':
            raise RuntimeError("socket connection broken")
        chunks.append(chunk)
        bytes_recd = bytes_recd + len(chunk)
    result = ''.join(chunks)
    print "Received",result
    return result

# read from a socket until a certain character is encountered
# (keep reading until all wanted characters received)
def full_receive_until (sock,char):
    chunks = []
    while True:
        chunk = sock.recv(1)
        if chunk == '':
            raise RuntimeError("socket connection broken")
        if chunk == char: 
            result = ''.join(chunks)
            print "Received",result
            return result
        chunks.append(chunk)


# These functions implement the server-side of the protocol

def send_level (sock,level):
    s = [ str(i) for i in level]
    full_send(sock,''.join(s))

def recv_move (sock):
    return full_receive_until(sock,".")

def send_chars (sock,player,baddies):
    s = [str(player.position())]
    s.extend([ str(b.position()) for b in baddies])
    full_send(sock,(','.join(s))+".")


# The event queue

class EventQueue (object):
    def __init__ (self):
        self._contents = []

    # list kept ordered by time left before firing
    def enqueue (self,when,obj):
        for (i,entry) in enumerate(self._contents):
            if when < entry[0]:
                self._contents.insert(i,[when,obj])
                break
        else:
            self._contents.append([when,obj])

    def ready (self):
        if self._contents:
            return (self._contents[0][0]==0)
        else:
            return False
        
    def dequeue_if_ready (self):
        acted = self.ready()
        while self.ready():
            entry = self._contents.pop(0)
            entry[1].event(self)
        for entry in self._contents:
            entry[0] -= 1


MOVE = {
    'Left': (-1,0),
    'Right': (1,0),
    'Up' : (0,-1),
    'Down' : (0,1)
}


# Event class to read a move from the playing client at 
# regular intervals

class ReceiveMove (Eventable):
    def __init__ (self,sock,player,baddies):
        self._player = player
        self._sock = sock
        self._baddies = baddies

    def event (self,q):
        send_chars (self._sock,self._player,self._baddies)
        move = recv_move(self._sock)
        if move != "":
            if move == "quit":
                self._sock.close()
                exit(0)
            (dx,dy) = MOVE[move]
            self._player.move(dx,dy)
            if self._player.at_exit():
                won (self._sock)
                self._sock.close()
                exit(0)
        self.requeue(q)



# the main loop

def play (sock):

    level = create_level()

    send_level(sock,level)

    p = Player(10,18,sock,level)

    q = EventQueue()

    b1 = Baddie(5,1,sock,level,p).enqueue(q,10)
    b2 = Baddie(10,1,sock,level,p).enqueue(q,20)
    b3 = Baddie(15,1,sock,level,p).enqueue(q,30)

    ReceiveMove(sock,p,[b1,b2,b3]).enqueue(q,1)

    while True:
        q.dequeue_if_ready()
        # Not needed since the recv in ReceiveMove blocks...
        # time.sleep(0.01)




def main(port):

    # Create a listening socket to listen for connection attempts
    serversocket = socket.socket(socket.AF_INET, 
                                 socket.SOCK_STREAM)
    serversocket.bind(('',port))
    serversocket.listen(1)

    while True:
        # wait for a player to connect
        print "Waiting for player"
        (player1socket,address1) = serversocket.accept()
        play(player1socket)
        player1socket.close()
        

if __name__ == '__main__':
    if len(sys.argv) > 1:
        main(int(sys.argv[1]))
    else:
        print "Need a port number"
