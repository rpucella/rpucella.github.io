#
# An observing client for the maze server
#
# See the protocol in maze-server.py
#
# Just like the playing client, but this client never sends move()
# messages and only ever receives chars messages
#

from graphics import *
import sys
import socket

from ast import literal_eval as make_tuple


LEVEL_WIDTH = 20
LEVEL_HEIGHT = 20    

CELL_SIZE = 24
WINDOW_WIDTH = CELL_SIZE*LEVEL_WIDTH
WINDOW_HEIGHT = CELL_SIZE*LEVEL_HEIGHT


# This is all lifted directly from maze.py

def lost (sock,window):
    t = Text(Point(WINDOW_WIDTH/2+10,WINDOW_HEIGHT/2+10),'YOU LOST!')
    t.setSize(36)
    t.setTextColor('red')
    t.draw(window)
    window.getKey()
    send_move(sock,".")

def won (sock,window):
    t = Text(Point(WINDOW_WIDTH/2+10,WINDOW_HEIGHT/2+10),'YOU WON!')
    t.setSize(36)
    t.setTextColor('red')
    t.draw(window)
    window.getKey()
    send_move(sock,".")

def cell (level,x,y):
    return level[x+(y*LEVEL_WIDTH)]

def screen_pos (x,y):
    return (x*CELL_SIZE+10,y*CELL_SIZE+10)

def create_screen (level,window):
    screen = {}
    for y in range(LEVEL_HEIGHT):
        for x in range(LEVEL_WIDTH):
            if cell(level,x,y) != 0:
                (sx,sy) = screen_pos(x,y)
                elt = Rectangle(Point(sx+1,sy+1),
                                Point(sx+CELL_SIZE-1,sy+CELL_SIZE-1))
                elt.setFill('sienna')
                elt.draw(window)
                screen[(x,y)] = elt
    return screen



# Initialize characters on the screen

def init_chars (player,baddies):
    def image (pos,what):
        return Image(Point(pos[0]+CELL_SIZE/2,pos[1]+CELL_SIZE/2),what)
    (px,py) = player
    p_grobj = (px,py,image(screen_pos(px,py),"android.gif"))
    bs_grobj = [ (x,y,image(screen_pos(x,y),"red.gif")) for (x,y) in baddies]
    bs_grobj.insert(0,p_grobj)
    return bs_grobj

# Move characters on the screen to a new position

def move_chars (chars,coords):
    z = zip(chars,coords)
    for ((x,y,obj),(nx,ny)) in z:
        (sx,sy) = screen_pos(x,y)
        obj.move(-sx,-sy)
        (sx,sy) = screen_pos(nx,ny)
        obj.move(sx,sy)
    return [ (nx,ny,obj) for ((_,_,obj),(nx,ny)) in z]


# read a given number of characters from a socket
# (keep reading until all wanted characters received)
def full_receive (sock,length):
    chunks = []
    bytes_recd = 0
    while bytes_recd < length:
        chunk = sock.recv(min(length - bytes_recd, 2048))
        if chunk == '':
            raise RuntimeError("socket connection broken")
        chunks.append(chunk)
        bytes_recd = bytes_recd + len(chunk)
    result = ''.join(chunks)
    print "Received",result
    return result

# read from a socket until a certain character is encountered
# (keep reading until all wanted characters received)
def full_receive_until (sock,char):
    chunks = []
    while True:
        chunk = sock.recv(1)
        if chunk == '':
            raise RuntimeError("socket connection broken")
        if chunk == char: 
            result = ''.join(chunks)
            print "Received",result
            return result
        chunks.append(chunk)



# functions implementing the client-side of the protocol

def recv_level (sock):
    return full_receive(sock,LEVEL_WIDTH * LEVEL_HEIGHT)

def recv_chars (sock):
    r = full_receive_until(sock,".")
    if r in ["won","lost"]:
        return r
    return make_tuple(r)
    

# the main loop

def play (port):

    window = GraphWin("Observer Client for Maze", 
                      WINDOW_WIDTH+20, WINDOW_HEIGHT+20,autoflush=False)

    rect = Rectangle(Point(5,5),Point(WINDOW_WIDTH+15,WINDOW_HEIGHT+15))
    rect.setFill('sienna')
    rect.setOutline('sienna')
    rect.draw(window)
    rect = Rectangle(Point(10,10),Point(WINDOW_WIDTH+10,WINDOW_HEIGHT+10))
    rect.setFill('white')
    rect.setOutline('white')
    rect.draw(window)

    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.connect(("localhost",port))

    print "connection established"

    level = [ int(i) for i in recv_level(s)]

    screen = create_screen(level,window)

    coords = recv_chars(s)
    chars = init_chars(coords[0],coords[1:])
    for (_,_,obj) in chars:
        obj.draw(window)
    
    MOVE = ["Left","Right","Up","Down"]

    previous = []

    while True:
        coords = recv_chars(s)
        if coords =="won":
            won(s,window)
            s.close()
            window.close()
            exit(0)
        if coords =="lost":
            lost(s,window)
            s.close()
            window.close()
            exit(0)
        if coords != previous:
            chars = move_chars(chars,coords)
            window.update()
            previous = coords
        # No need, since blocking on recv_chars()
        # time.sleep(0.005)


if __name__ == '__main__':
    if len(sys.argv) > 1:
        play(int(sys.argv[1]))
    else:
        print "Need a port number"
