
module Exp where

{-

An expression is either:

  an identifier:       ID
  a function:          /ID -> E
  an application:      E1 E2
  an integer literal:  INT (such as 1, 2, 3, 4)
  a conditional:       if E1 then E2 else E3
  a local definition:  let ID = E1 in E2
  a recursive def:     letrec ID ID = E1 in E2

Example of a recursive definition:
  
  letrec sumto n = if (iszero n) then 0 else add n (sumto (add n -1)) in sumto 10

-}

data Exp =
  Eid String |
  Efun String Exp |
  Eapp Exp Exp |
  Eint Int |
  Eif Exp Exp Exp |
  Elet String Exp Exp |
  Eletrec String String Exp Exp 
    deriving (Show)

pp (Eid x) = x
pp (Efun x e) = "(/" ++ x ++ " -> " ++ pp e ++ ")"
pp (Eapp e1 e2) = (pp e1) ++ " " ++ (pp e2)
pp (Eint i) = show i
pp (Eif e1 e2 e3) = "if " ++ (pp e1) ++ " then " ++ (pp e2) ++ " else " ++ (pp e3)
pp (Elet s e1 e2) = "let " ++ s ++ " = " ++ (pp e1) ++ " in " ++ (pp e2)
pp (Eletrec f s e1 e2) = "letrec " ++ f ++ " " ++ s ++ " = " ++ (pp e1) ++ " in " ++ (pp e2)

