
module Eval (
  eval
) where


-- EVALUATOR ----------------------------------------------------------

import Exp
import Parser
import Data.Char

{-

A value is either:

  an integer
  a Boolean
  a function (closure) with parameter name, body, and definition-time environment
  a primitive operation implemented as a Haskell function Value -> Value

Additionally, to support recursive functions, we need a version of a closure that
knows the name of the function it is bound to (to support recursive). This is what
the VRec creates.

Note that strictly speaking we don't need both a Vfun and a Vrec, since could
represent a Vfun with a Vrec by perhaps making the self name a Maybe value, but
for clarity, I'm keeping both.

-}

data Value =
  Vint Int |
  Vbool Bool | 
  Vfun String Exp Env |
  Voper (Value -> Value) |
  Vrec String String Exp Env

instance Show Value where
  show = showValue

showValue (Vint i) = show i
showValue (Vbool b) = show b
showValue (Vfun s e env) = pp (Efun s e)
showValue (Vrec f s e env) = "(rec " ++ f ++ " " ++ s ++ " -> " ++ (pp e) ++ ")"
showValue (Voper f) = "<operation>"

data Env = Env [(String, Value)]
  deriving (Show)

addEnv (Env env) name value =
  Env ((name, value) : env)

lookupEnv (Env env) name =
  case lookup name env of 
    Just val -> val
    Nothing -> error ("unbound identifier " ++ name)


-- Call-by-value semantics.

eval :: Env -> Exp -> Value

eval env (Eid s) = lookupEnv env s
eval env (Efun s e) = Vfun s e env
eval env (Eapp e1 e2) =
  let v1 = eval env e1
      v2 = eval env e2
  in case v1 of
    Vfun s e env1 -> eval (addEnv env1 s v2) e
    Vrec f s e env1 -> eval (addEnv (addEnv env1 s v2) f v1) e
    Voper f -> f v2
    _ -> error "Cannot apply a non-function"
eval env (Eint i) = Vint i
eval env (Eif e1 e2 e3) =
  let v1 = eval env e1
  in case v1 of
       Vbool True -> eval env e2
       Vbool False -> eval env e3
       _ -> error "Condition not a Boolean"
eval env (Elet s e1 e2) =
  let v1 = eval env e1
  in eval (addEnv env s v1) e2
eval env (Eletrec f s e1 e2) =
  let v1 = Vrec f s e1 env
  in eval (addEnv env f v1) e2


{- The implementation of the primitive operations
   Primitive operations are bound in the initial
   environment `initEnv`
-}

oper_iszero (Vint i) = Vbool (i == 0)
oper_iszero _ = error "Operation iszero requires an int"

oper_add1 i1 (Vint i2) = Vint (i1 + i2)
oper_add1 i1 _ = error "Operation add requires ints"

oper_add (Vint i1) = Voper (oper_add1 i1)
oper_add _ = error "Operation add requires ints"

oper_mult1 i1 (Vint i2) = Vint (i1 * i2)
oper_mult1 i1 _ = error "Operation mult requires ints"

oper_mult (Vint i1) = Voper (oper_mult1 i1)
oper_mult _ = error "Operation mult requires ints"

oper_neg (Vint i1) = Vint (-i1)
oper_neg _ = error "Operation neg requires an int"

initEnv = Env [
    ("true", Vbool True),
    ("false", Vbool False),
    ("iszero", Voper oper_iszero),
    ("add", Voper oper_add),
    ("mult", Voper oper_mult),
    ("neg", Voper oper_neg)
  ]

{- A shortcut function that takes an expression as a string,
   parses it, then evaluates it in the initial environment.
-}

ev s = eval initEnv (parse s)

