
module Parser where


{-

  Parsing code borrowed from Hutton and Meijer "Monadic Parsing in Haskell"
  
  https://www.cs.nott.ac.uk/~pszgmh/pearl.pdf

  It exports function  parse :: String -> Exp
     
-}

-- PARSING LIBRARY ----------------------------------------------------------

import Exp
import Control.Monad
import Data.Char

newtype Parser a = Parser (String -> [(a, String)])

instance Functor Parser where
  fmap = liftM

instance Applicative Parser where
  pure a = Parser (\cs -> [(a, cs)])
  (<*>) = ap

instance Monad Parser where
  p >>= f = Parser (\cs -> concat [parseCS (f a) cs' | (a,cs') <- parseCS p cs])

parseCS (Parser p) = p

class Monad m => MyMonadPlus m where
  zero :: m a
  plus :: m a -> m a -> m a

instance MyMonadPlus Parser where
  zero = Parser (\cs -> [])
  p `plus` q = Parser (\cs -> parseCS p cs ++ parseCS q cs)

(+++) :: Parser a -> Parser a -> Parser a
p +++ q = Parser (\cs -> case parseCS (p `plus` q) cs of
                           [] -> []
                           (x:xs) -> [x])
item :: Parser Char
item = Parser (\cs -> case cs of
                        "" -> []
                        (c:cs) -> [(c, cs)])

sat :: (Char -> Bool) -> Parser Char
sat p = do {c <- item; if p c then pure c else zero}

char :: Char -> Parser Char
char c = sat (c ==)

pfail :: Parser a
pfail = Parser (\cs -> [])

string :: String -> Parser String
string "" = return ""
string (c:cs) = do {char c; string cs; return (c:cs)}

many :: Parser a -> Parser [a]
many p = many1 p +++ return []

many1 :: Parser a -> Parser [a]
many1 p = do {a <- p; as <- many p; return (a:as)}

sepby :: Parser a -> Parser b -> Parser [a]
p `sepby` sep = (p `sepby1` sep) +++ return []

sepby1 :: Parser a -> Parser b -> Parser [a]
p `sepby1` sep = do a <- p
                    as <- many (do {sep; p})
                    return (a:as)

chainl :: Parser a -> Parser (a -> a -> a) -> a -> Parser a
chainl p op a = (p `chainl1` op) +++ return a

chainl1 :: Parser a -> Parser (a -> a -> a) -> Parser a
p `chainl1` op = do {a <- p; rest a}
                 where
                   rest a = (do f <- op
                                b <- p
                                rest (f a b))
                            +++ return a

space :: Parser String
space = many (sat isSpace)

token :: Parser a -> Parser a
token p = do {a <- p; space; return a}

symb :: String -> Parser String
symb cs = token (string cs)

apply :: Parser a -> String -> [(a,String)]
apply p = parseCS (do {space; p})


-- PARSER ----------------------------------------------------------

parse :: String -> Exp
parse s =
  case (apply expr s) of
    [] -> error "Cannot parse string"
    (t, ""):_ -> t
    (t, lft):_ -> error ("Cannot parse at " ++ lft)

expr :: Parser Exp
expr =
  exprIf +++ exprLet +++ exprLetrec +++ exprApp

exprIf :: Parser Exp
exprIf = do symb "if"
            e1 <- expr
            symb "then"
            e2 <- expr
            symb "else"
            e3 <- expr
            return (Eif e1 e2 e3)

exprLet :: Parser Exp
exprLet = do symb "let"
             id <- ident
             char '='
             space
             e1 <- expr
             symb "in"
             e2 <- expr
             return (Elet id e1 e2)

exprLetrec :: Parser Exp
exprLetrec = do symb "letrec"
                idf <- ident
                idx <- ident 
                char '='
                space
                e1 <- expr
                symb "in"
                e2 <- expr
                return (Eletrec idf idx e1 e2)

exprApp :: Parser Exp
exprApp = do ts <- many1 term
             return (foldl1 (\r -> \a -> Eapp r a) ts)

term :: Parser Exp
term =
  termLam +++
  termInt +++
  termIdent +++
  termParen

keywords = ["let", "letrec", "in", "if", "then", "else"]

ident :: Parser String
ident = do s1 <- sat (\c -> isAlpha c || c == '_')
           s2 <- many (sat (\c -> isAlpha c || isDigit c || c == '_'))
           space
           if (s1 : s2) `elem` keywords
             then pfail
           else return (s1 : s2)

termIdent :: Parser Exp
termIdent = do s <- ident
               return (Eid s)

termPosInt = do s <- many1 (sat (\c -> isDigit c))
                space
                return s

termNegInt = do char '-'
                s <- termPosInt
                return ("-" ++ s)
                
termInt = do s <- (termNegInt +++ termPosInt)
             return (Eint (read s))

termLam :: Parser Exp
termLam = do char '/'
             s <- ident
             char '-'
             char '>'
             space
             t <- expr
             space 
             return (Efun s t)

termParen :: Parser Exp
termParen = do char '('
               t <- expr
               char ')'
               space
               return t

