
# Extended Lambda Calculus Evaluator

Split into three modules (files):

- `Exp.hs`: the basic `Exp` type for the internal representation
   of lambda calculus expressions
- `Parser.hs`: the parser that takes strings in the source lambda
   calculus and translates them into the corresponding internal
   representation
- `LC.hs`: the evaluation function that takes lambda calculus
   expressions in the internal representation and evaluates them
   to values

Details of the internal representation are given in the `Exp.hs` file.

The parser is adapted from Hutton and Meijer's [_Monadic Parsing in Haskell_](https://www.cs.nott.ac.uk/~pszgmh/pearl.pdf).

A simple interaction with the evaluator, assuming you run `ghci`
from the folder containing the lambda calculus evaluator:

    ghci> :l LC
    [1 of 3] Compiling Exp              ( Exp.hs, interpreted )
    [2 of 3] Compiling Parser           ( Parser.hs, interpreted )
    [3 of 3] Compiling Eval             ( LC.hs, interpreted )
    Ok, three modules loaded.
    
    ghci> ev "add 10 20"
    30
    
    ghci> ev "let x = mult 3 4 in add (neg x) 1"
    -11
    
    ghci> ev "letrec sumto n = if (iszero n) then 0 else add n (sumto (add n -1)) in sumto 10"
    55
